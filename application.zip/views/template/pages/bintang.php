<?php 

for( $a=10;$a>0;$a--)
{
for($b=10;$b>$a;$b--)
{
echo "*";
}
echo" ";
}

 ?>