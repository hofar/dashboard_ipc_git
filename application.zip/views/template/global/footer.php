<!-- BEGIN FOOTER -->


<!--<script src="<?php echo base_url(); ?>assets/template/global/plugins/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/template/global/plugins/jquery-migrate.min.js" type="text/javascript"></script>
<!-- IMPORTANT! Load jquery-ui.min.js before bootstrap.min.js to fix bootstrap tooltip conflict with jquery ui tooltip -->
<!--<script src="<?php echo base_url(); ?>assets/template/global/plugins/jquery-ui/jquery-ui.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/template/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
 <script src="<?php echo base_url(); ?>assets/template/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script> -->
 <script src="<?php echo base_url(); ?>assets/template/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<!-- <script src="<?php echo base_url(); ?>assets/template/global/plugins/jquery.blockui.min.js" type="text/javascript"></script> -->
<!-- <script src="<?php echo base_url(); ?>assets/template/global/plugins/jquery.cokie.min.js" type="text/javascript"></script> -->
<!-- <script src="<?php echo base_url(); ?>assets/template/global/plugins/uniform/jquery.uniform.min.js" type="text/javascript"></script> -->
<!-- <script src="<?php echo base_url(); ?>assets/template/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script> -->
<!-- END CORE PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<!-- <script src="<?php echo base_url(); ?>assets/template/global/plugins/jqvmap/jqvmap/jquery.vmap.js" type="text/javascript"></script> -->
<!-- <script src="<?php echo base_url(); ?>assets/template/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.russia.js" type="text/javascript"></script> -->
<!-- <script src="<?php echo base_url(); ?>assets/template/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.world.js" type="text/javascript"></script> -->
<!-- <script src="<?php echo base_url(); ?>assets/template/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.europe.js" type="text/javascript"></script> -->
<!-- <script src="<?php echo base_url(); ?>assets/template/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.germany.js" type="text/javascript"></script> -->
<!-- <script src="<?php echo base_url(); ?>assets/template/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.usa.js" type="text/javascript"></script> -->
<!-- <script src="<?php echo base_url(); ?>assets/template/global/plugins/jqvmap/jqvmap/data/jquery.vmap.sampledata.js" type="text/javascript"></script> -->

<!-- BEGIN PAGE LEVEL SCRIPTS -->
<!--
<script src="<?php echo base_url(); ?>assets/template/global/scripts/metronic.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/template/admin/layout4/scripts/layout.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/template/admin/layout4/scripts/demo.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/template/admin/pages/scripts/index3.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/template/admin/pages/scripts/tasks.js" type="text/javascript"></script>

<!-- <script type="text/javascript" src="<?php echo base_url(); ?>assets/template/global/plugins/datatables/plugins/bootstrap/jquery.dataTables.min.js"></script> -->
<!-- <script type="text/javascript" src="<?php echo base_url(); ?>assets/template/global/plugins/datatables/extensions/TableTools/js/dataTables.tableTools.min.js"></script> -->
<!-- <script type="text/javascript" src="<?php echo base_url(); ?>assets/template/global/plugins/datatables/extensions/ColReorder/js/dataTables.colReorder.min.js"></script> -->
<!-- <script type="text/javascript" src="<?php echo base_url(); ?>assets/template/global/plugins/datatables/extensions/Scroller/js/dataTables.scroller.min.js"></script> -->
<!--<script type="text/javascript" src="<?php echo base_url(); ?>assets/template/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js"></script>-->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/template/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/template/admin/pages/scripts/table-advanced.js"></script>
<script src="<?php echo base_url(); ?>assets/form-validator/jquery.form-validator.min.js"></script>
<script src="<?php echo base_url(); ?>assets/template/admin/pages/scripts/components-pickers.js"></script>

<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
<script src="https://www.amcharts.com/lib/3/amcharts.js"></script>
<script src="https://www.amcharts.com/lib/3/serial.js"></script>
<script src="https://www.amcharts.com/lib/3/pie.js"></script>
<script src="https://www.amcharts.com/lib/3/gauge.js"></script>
<!-- <script src="https://www.amcharts.com/lib/3/ammap_amcharts_extension.js"></script> -->
<!-- <script src="https://www.amcharts.com/lib/3/maps/js/continentsLow.js"></script> -->
<!-- <script src="https://www.amcharts.com/lib/3/plugins/export/export.min.js"></script> -->
<script src="https://www.amcharts.com/lib/3/themes/light.js"></script>
<!--<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>-->
<!-- <script src="//cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script> -->
<script src="<?php echo base_url(); ?>assets/ammap/ammap/maps/js/indonesiaLow.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/ammap/ammap/ammap.js" type="text/javascript"></script>
<script src="https://www.amcharts.com/lib/3/themes/dark.js"></script>

<script src="<?php echo base_url(); ?>assets_remark/global/vendor/aspieprogress/jquery-asPieProgress.js"></script>
<script src="<?php echo base_url(); ?>assets_remark/global/js/Plugin/aspieprogress.js"></script>
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>
<script>
    $.validate({
        modules: 'security'
    });

    // plugin number format
    function number_format(number, decimals, decPoint, thousandsSep){
        decimals = decimals || 0;
        number = parseFloat(number);

        if(!decPoint || !thousandsSep){
            decPoint = '.';
            thousandsSep = ',';
        }

        var roundedNumber = Math.round( Math.abs( number ) * ('1e' + decimals) ) + '';
        var numbersString = decimals ? roundedNumber.slice(0, decimals * -1) : roundedNumber;
        var decimalsString = decimals ? roundedNumber.slice(decimals * -1) : '';
        var formattedNumber = "";

        while(numbersString.length > 3){
            formattedNumber += thousandsSep + numbersString.slice(-3)
            numbersString = numbersString.slice(0,-3);
        }

        return (number < 0 ? '-' : '') + numbersString + formattedNumber + (decimalsString ? (decPoint + decimalsString) : '');
    }
</script>

<script>
    /*$(document).ready(function () {
        $('#table').DataTable({
            searching: false,
            lengthChange: false,
            bSort: false,
            // target: 'no-sort',
        });
    });

    $(document).ready(function () {
        $('#table2').DataTable({
            searching: false,
            lengthChange: false,
            bSort: false,
            // target: 'no-sort',
        });
    });

    jQuery(document).ready(function () {
        Metronic.init(); // init metronic core componets
        Layout.init(); // init layout
        Demo.init(); // init demo features 
        ComponentsPickers.init();
        Index.init(); // init index page
        Tasks.initDashboardWidget(); // init tash dashboard widget  
        TableAdvanced.init();

    });*/
</script>

<script>
    // gauge +='<div class="pie-progress pie-progress-sm" data-plugin="pieProgress" data-valuemax="100" data-barcolor="#57c7d4" data-size="100" data-barsize="10" data-goal="100" aria-valuenow="86" role="progressbar">\
    //              <span class="pie-progress-number blue-grey-700 font-size-20">\
    //                  86%\
    //              </span>\
    //          </div>';


    var map = AmCharts.makeChart("chartdiv", {
        "type": "map",
        "theme": "dark",
        "colorSteps": 10,
        "areasSettings": {
            "autoZoom": true,
            "selectedColor": "#F60",
            "color" : "#144967",
            "outlineColor" : "#ffffff",
            "outlineThickness" : 1.5,
            "selectedOutlineColor" : "#ffffff",
            "rollOverColor" : "#F60",
            "rollOverOutlineColor" : "#ffffff"

        },
        "zoomControl": {
            "maxZoomLevel": 1000
            /*"zoomControlEnabled":false,
            "homeButtonEnabled":false,
            "minZoomLevel":1.5,
            "maxZoomLevel" :1.5,
            "zoomFactor":1,
            "right" : 0,
            "left" : 0 */
        },

        "dataProvider": {
            "map": "indonesiaLow",
            "getAreasFromMap": true,
            "images": [
<?php foreach ($get_cabang as $rowcabang) { ?>
                    {
                        "title": "<?php echo $rowcabang->DISPLAY_NAME; ?>",
                        "latitude": <?php echo $rowcabang->LATITUDE; ?>,
                        "longitude": <?php echo $rowcabang->LONGITUDE; ?>,
                        "width": 70,
                        "height": 60,
                        "gauge": {
                            "type": "gauge",
                            "theme": "light",
                            "axes": [{
                                    "axisThickness": 1,
                                    "axisAlpha": 0,
                                    "tickAlpha": 0,
                                    "inside": true,
                                    "bandOutlineAlpha": 0,
                                    "gridInside": true,
                                    "labelsEnabled": false,
                                    "bands": [{
                                            "balloonText": "Realisasi",
                                            "color": "#EF4423",
                                            "endValue": 100,
                                            "startValue": 0
                                        }],
                                    "bottomText": '<?php foreach ($get_gauge_value as $list): 
                                                        if ($list->BRANCH_ID == $rowcabang->BRANCH_ID) {
                                                            if ($list->NILAI_GAUGE > 0) {
                                                                echo round($list->NILAI_GAUGE).'%';
                                                            }
                                                            else{
                                                                echo '0%';
                                                            }
                                                         }?>\
                                                    <?php endforeach; ?>',
                                                    "bottomTextFontSize": 9,
                                    "bottomTextYOffset": -1,
                                    "endValue": 100,
                                    "listeners": [{
                                            "event": "clickBand",
                                            "method": function(event){
                                                id_branch = '<?php echo $rowcabang->BRANCH_ID; ?>';
                                                id_branch_sess = '<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>'
                                                user_priv = '<?php echo $this->session->userdata('SESS_USER_PRIV') ?>'
                                                user_posit = '<?php echo $this->session->userdata('SESS_USER_POSITION') ?>'
                                               // console.log(user_posit);
                                               if (user_priv == 2 && user_posit == 2) {
                                                        if (id_branch == id_branch_sess) {
                                                            coba(id_branch);
                                                       }
                                                       else{

                                                       }
                                               }
                                               else if (user_priv == 2 && user_posit == 4) {
                                                        if (id_branch == id_branch_sess) {
                                                            coba(id_branch);
                                                       }
                                                       else{

                                                       }
                                               }
                                               else if(user_priv == 3 && user_posit == 2){
                                                    if (id_branch == id_branch_sess) {
                                                            coba(id_branch);
                                                       }
                                                       else{

                                                       }
                                               }
                                               else if(user_priv == 3 && user_posit == 4){
                                                    if (id_branch == id_branch_sess) {
                                                            coba(id_branch);
                                                       }
                                                       else{

                                                       }
                                               }
                                               else if(user_priv == 1 && user_posit == 1){
                                                    coba(id_branch);
                                               }
                                               else if(user_priv == 1 && user_posit == 2){
                                                    coba(id_branch);
                                               }
                                               else if(user_priv == 1 && user_posit == 3){
                                                    coba(id_branch);
                                               }
                                               else if(user_priv == 1 && user_posit == 4){
                                                    coba(id_branch);
                                               }
                                                // profil(id_branch);
                                            }
                                        }]
                                }],
                            "arrows": [{"value": '<?php foreach ($get_gauge_value as $list): 
                                                        if ($list->BRANCH_ID == $rowcabang->BRANCH_ID) {
                                                            if ($list->NILAI_GAUGE > 0) {
                                                                echo round($list->NILAI_GAUGE);
                                                            }
                                                            else{
                                                                echo '0';
                                                            }
                                                         }?>\
                                                    <?php endforeach; ?>'}],
                            "allLabels": [
                                {
                                    "text": "<?php echo $rowcabang->BRANCH_NAME; ?>",
                                    "bold": true,
                                    "size": 9,
                                    "x": 10,
                                    "y": 50
                                }
                            ],
                            "export": {
                                "enabled": true
                            }
                        }
                    },
<?php } ?>
            ]
        },

        "listeners": [{
                "event": "positionChanged",
                "method": updateCustomMarkers
            }, {
                "event": "rendered",
                "method": klikKota
            }
        ]

    });
    //
    function coba(id_branch) {
        // alert(id_branch)
        $('#placeholder').hide();
            // profil(id_branch);
        $('#placeholder').show(function(){
            $.ajax({
                url:"<?php echo base_url() ?>home/detail/" + id_branch,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);
                    $('#cabang').text(data.data['DISPLAY_NAME']);
                    $('#realisasi_fisik').text(data.data2['REALISASI_FISIK']);
                    $('#value_fisik').text(data.data13['REAL_SUBPRO_VAL']);
                    $('#value_program').text(data.data3['JML2'] + ' Program Berjalan');

                    var value = parseFloat(data.data15['VALUE_REALISASI']).toFixed(2);
                    var set_value = value.replace(".", ",");
                    var fix_value = "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");

                    $('#value_realisasi').text(fix_value);

                    var get_realisasi = parseFloat(data.data2['REALISASI_FISIK']).toFixed(2);
                    var realisasi = get_realisasi.replace(".", ",");

                    var get_program = parseFloat(data.data3['KPI_REALISASI_PROGRAM']).toFixed(2);
                    var program = get_program.replace(".", ",");

                    var get_fisik = parseFloat(data.data4['KPI_REALISASI_FISIK']).toFixed(2);
                    var fisik = get_fisik.replace(".", ",");


                        
                    

                    //detail yayan-gauge
                    //awal realisasi fisik
                     var dt1d = parseFloat(data.data2['REALISASI_FISIK']).toFixed(2);
                        var dt2d = 100-dt1d;
                        var donut1d = Morris.Donut({
                        element: 'graph1d',
                        data: [
                            {label: data.data2['RE'], value: dt1d},
                            {label: '', value: dt2d}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#009688',
                            '#ff3d00',
                        ],
                        formatter: function (x) { return x + "%"}
                        });
                        
                        //awal program berjalan
                        var dt3d = parseFloat(data.data3['JML1'] / data.data3['JML2'] * 100).toFixed(2);
                        var dt4d = 100 - dt3d;
                        var donut2d = Morris.Donut({
                        element: 'graph2d',
                        data: [
                            {value: dt3d, label: data.data3['JML1']+"/"+data.data3['JML2']},
                            {value: dt4d, label: data.data3['JML1']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#009688',
                            '#ff3d00',
                        ],
                        formatter: function (x) { return x + "%"}
                        });
                        
                        //awal kpi realisasi fisik
                        var dt5d = parseFloat(data.data4['KPI_REALISASI_FISIK']).toFixed(2);
                        var dt6d = 100 - dt5d;
                        var donut3d = Morris.Donut({
                        element: 'graph3d',
                        data: [
                            {value: dt5d, label: data.data2['RE']},
                            {value: dt6d, label: data.data2['RE']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#009688',
                            '#ff3d00',
                        ],
                        formatter: function (x) { return x + "%"}
                        });
                    
                    /*Status Program Investasi*/
                    var gaugeChart = AmCharts.makeChart("pieDetails4", {
                        "type": "pie",
                        "pullOutRadius": 0,
                        "labelRadius": 0,
                        "radius": "35%",
                        "dataProvider": [{
                                "category": "Berjalan",
                                "color": "#009688",
                                "value": data.data3['JML1']
                            }, {
                                "category": "Belum Berjalan",
                                "color": "#EF4423",
                                "value": data.data3['BELUMBERJALAN']
                            }],
                            "labelText": "",
                            "colorField": "color",
                            "valueField": "value",
                        "titleField": "category"
                    });
                    
                    /*Kendala*/
                    var data_kendala = [];

                    $.each(data.data8, function(key, val){

                        if (val.REAL_SUBPRO_CONSTRAINTS == 1)
                            var color = "#FF0F00";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 2)
                            var color = "#FF6600";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 3)
                            var color = "#FF9E01";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 4)
                            var color = "#FCD202";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 5)
                            var color = "#F8FF01";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 6)
                            var color = "#B0DE09";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 7)
                            var color = "#04D215";

                        data_kendala.push ( {
                            "country": val.CONTRAINTS_NAME,
                            "visits": val.TOTAL_KENDALA,
                            "color": color
                        });
                    });

                    var chart = AmCharts.makeChart("tabung2", {
                        "type": "serial",
                        "theme": "none",
                        // "marginRight": 100,
                        "dataProvider": data_kendala,
                        "valueAxes": [{
                                "axisAlpha": 0,
                                "position": "left",
                                "title": "jumlah"
                            }],
                        "startDuration": 1,
                        "graphs": [{
                                "balloonText": "<b>[[category]]: [[value]]</b>",
                                "fillColorsField": "color",
                                "fillAlphas": 0.9,
                                "lineAlpha": 0.2,
                                "type": "column",
                                "valueField": "visits"
                            }],
                        "chartCursor": {
                            "categoryBalloonEnabled": false,
                            "cursorAlpha": 0,
                            "zoomable": false
                        },
                        "categoryField": "country",
                        "categoryAxis": {
                            "gridPosition": "start",
                            "labelRotation": 45
                        },
                        "export": {
                            "enabled": false
                        }

                    });

                    /*Posisi*/
                    var data_posisi = [];

                    $.each(data.data7, function(key, val){

                        if (val.RKAP_INVS_POS == 1)
                            var color = "#FF0F00";
                        else if (val.RKAP_INVS_POS == 2)
                            var color = "#FF6600";
                        else if (val.RKAP_INVS_POS == 3)
                            var color = "#FF9E01";
                        else if (val.RKAP_INVS_POS == 4)
                            var color = "#FCD202";
                        else if (val.RKAP_INVS_POS == 5)
                            var color = "#F8FF01";
                        else if (val.RKAP_INVS_POS == 6)
                            var color = "#B0DE09";
                        else if (val.RKAP_INVS_POS == 7)
                            var color = "#04D215";
                        else if (val.RKAP_INVS_POS == 8)
                            var color = "#0D8ECF";
                        else if (val.RKAP_INVS_POS == 9)
                            var color = "#0D52D1";
                        else if (val.RKAP_INVS_POS == 10)
                            var color = "#2A0CD0";
                        else if (val.RKAP_INVS_POS == 11)
                            var color = "#8A0CCF";
                        else if (val.RKAP_INVS_POS == 12)
                            var color = "#CD0D74";
                        else if (val.RKAP_INVS_POS == 13)
                            var color = "#04D215";

                        data_posisi.push ( {
                            "country": val.POSISI,
                            "visits": val.JUMLAH_POSISI,
                            "color": color
                        });
                    });

                    var posisi_investasi = "";

                    $.each(data.data7, function(key, val){

                        if (val.RKAP_INVS_POS == 1) 
                            var src = "<?php echo base_url(); ?>/assets/flat/charts.png?>";
                        else if (val.RKAP_INVS_POS == 2)
                            var src = "<?php echo base_url(); ?>/assets/flat/statistics2.png?>";
                        else if (val.RKAP_INVS_POS == 3)
                            var src = "<?php echo base_url(); ?>/assets/flat/planning.jpg?>";
                        else if (val.RKAP_INVS_POS == 4)
                            var src = "<?php echo base_url(); ?>/assets/flat/map.png?>";
                        else if (val.RKAP_INVS_POS == 5)
                            var src = "<?php echo base_url(); ?>/assets/flat/job-search.png?>";
                        else if (val.RKAP_INVS_POS == 6)
                            var src = "<?php echo base_url(); ?>/assets/flat/auction.png?>";
                        else if (val.RKAP_INVS_POS == 7)
                            var src = "<?php echo base_url(); ?>/assets/flat/vector.png?>";
                        else if (val.RKAP_INVS_POS == 8)
                            var src = "<?php echo base_url(); ?>/assets/flat/melt.png?>";
                        else if (val.RKAP_INVS_POS == 9)
                            var src = "<?php echo base_url(); ?>/assets/flat/statistics.png?>";
                        else if (val.RKAP_INVS_POS == 10)
                            var src = "<?php echo base_url(); ?>/assets/flat/chronometer.png?>";
                        else if (val.RKAP_INVS_POS == 11)
                            var src = "<?php echo base_url(); ?>/assets/flat/recycling-plant.png?>";
                        else if (val.RKAP_INVS_POS == 12)
                            var src = "<?php echo base_url(); ?>/assets/flat/construction.png?>";
                        else if (val.RKAP_INVS_POS == 13)
                            var src = "<?php echo base_url(); ?>/assets/flat/approve.png?>";

                        posisi_investasi += '<li class="list-group-item">\
                            <div class="media" style="border-bottom:1px solid #e5e7ea; padding-bottom : 10px;">\
                                <div class="pr-20">\
                                <a class="avatar-md" href="javascript:void(0)">\
                                    <img class="img-responsive" style="height:45px" src="'+ src +'" alt="...">\
                                </a>\
                                </div>\
                                <div class="media-body">\
                                    <h5 class="mt-0 mb-5">' + val.POSISI + '</h5>\
                                    <p>' + val.JUMLAH_POSISI + '</p>\
                                </div>\
                            </div>\
                        </li>';

                    });
                    
                    $('#posisi_investasi').html(posisi_investasi);

                    var kendala_investasi = "";

                    $.each(data.data8, function(key, val){

                        kendala_investasi += '<h5>' + val.CONTRAINTS_NAME + '\
                              <span class="float-right">' + val.TOTAL_KENDALA + '</span>\
                            </h5>\
                            <div class="progress progress-sm">\
                              <div  class="progress-bar bg-info1 active" style="width: ' + val.TOTAL_KENDALA + '%; margin-right:50px !IMPORTANT" role="progressbar"></div>\
                            </div>';

                    });
                    
                    $('#kendala_investasi').html(kendala_investasi);

                    var chart = AmCharts.makeChart("tabung1", {
                        "type": "serial",
                        "theme": "none",
                        // "marginRight": 70,
                        "dataProvider": data_posisi,
                        "valueAxes": [{
                                "axisAlpha": 0,
                                "position": "left",
                                "title": "jumlah"
                            }],
                        "startDuration": 1,
                        "graphs": [{
                                "balloonText": "<b>[[category]]: [[value]]</b>",
                                "fillColorsField": "color",
                                "fillAlphas": 0.9,
                                "lineAlpha": 0.2,
                                "type": "column",
                                "valueField": "visits"
                            }],
                        "chartCursor": {
                            "categoryBalloonEnabled": false,
                            "cursorAlpha": 0,
                            "zoomable": false
                        },
                        "categoryField": "country",
                        "categoryAxis": {
                            "gridPosition": "start",
                            "labelRotation": 45
                        },
                        "export": {
                            "enabled": false
                        }

                    });

                    var good = data.data12['ABC'] / 3;
                    var fair = good * 2;
                    var poor = good * 3;
                    
                    /*detail kontrak kritis 1*/
                    var kk1d = parseFloat(data.data9['DEVIASI'] / data.data12['ABC'] * 100).toFixed(2);
                        var kk2d = 100 - kk1d;
                        var donut4d = Morris.Donut({
                        element: 'graph4d',
                        data: [
                            {value: kk1d, label: data.data9['DEVIASI']+"/"+data.data12['ABC']},
                            {value: kk2d, label: data.data9['DEVIASI']+"/"+data.data12['ABC']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#ff3d00',
                            '#009688'
                        ],
                        formatter: function (x) { return x + "%"}
                        });

                        /*awal kontrak kritis 2*/
                        var kk3d = parseFloat(data.data10['DEVIASI'] / data.data12['ABC'] * 100).toFixed(2);
                        var kk4d = 100 - kk3d;
                        var donut5d = Morris.Donut({
                        element: 'graph5d',
                        data: [
                            {value: kk3d, label: data.data10['DEVIASI']+"/"+data.data12['ABC']},
                            {value: kk4d, label: data.data10['DEVIASI']+"/"+data.data12['ABC']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#ff3d00',
                            '#009688'
                        ],
                        formatter: function (x) { return x + "%"}
                        });


                        /*awal kontrak kritis 3*/
                        var kk5d = parseFloat(data.data11['DEVIASI'] / data.data12['ABC'] * 100).toFixed(2);
                        var kk6d = 100 - kk5d;
                        var donut6d = Morris.Donut({
                        element: 'graph6d',
                        data: [
                            {value: kk5d, label: data.data11['DEVIASI']+"/"+data.data12['ABC']},
                            {value: kk6d, label: data.data11['DEVIASI']+"/"+data.data12['ABC']}
                        ],
                        labels: ['title one', 'title Two'],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#ff3d00',
                            '#009688'
                        ],
                        formatter: function (x) { return x + "%"}
                        });

                }
            })

            
        });
        
    }
    
    

    function klikKota(e) {
        var map = e.chart;
        map.initialZoomLevel = map.zoomLevel();
        map.initialZoomLatitude = map.zoomLatitude();
        map.initialZoomLongitude = map.zoomLongitude();
    }

    function updateCustomMarkers(event) {

        var map = event.chart;

        for (var x = 0; x < map.dataProvider.images.length; x++) {

            var image = map.dataProvider.images[x];

            if (image.gauge === undefined) {
                continue;
            }

            if (image.id === undefined) {
                image.id = "amcharts_gauge_" + x;
            }

            if ("undefined" == typeof image.gauge.theme) {
                image.gauge.theme = map.theme;
            }

            if ("undefined" == typeof image.externalElement) {
                image.externalElement = createCustomMarker(image);
            }

            var xy = map.coordinatesToStageXY(image.longitude, image.latitude);
            image.externalElement.style.top = xy.y + "px";
            image.externalElement.style.left = xy.x + "px";
            image.externalElement.style.marginTop = Math.round(image.height / -2) + "px";
            image.externalElement.style.marginLeft = Math.round(image.width / -2) + "px";
        }
    }

    function createCustomMarker(image) {

        var holder = document.createElement("div");
        holder.id = image.id;
        holder.title = image.title;
        holder.style.position = "absolute";
        holder.style.width = image.width + "px";
        holder.style.height = image.height + "px";

        image.chart.chartDiv.appendChild(holder);

        var chart = AmCharts.makeChart(image.id, image.gauge);

        return holder;
    }
</script>
<script>

    // gauge kritis pusat

    

    var gaugeChart = AmCharts.makeChart("gaugeKritis7", {
        "type": "gauge",
        "theme": "light",
        "axes": [{
                "axisThickness": 1,
                "axisAlpha": 0.2,
                "tickAlpha": 0.2,
                "labelsEnabled": false,
                "bands": [{
                        "balloonText": "Good",
                        "color": "#84b761",
                        "endValue": 30,
                        "startValue": 0
                    }, {
                        "balloonText": "Fair",
                        "color": "#fdd400",
                        "endValue": 70,
                        "startValue": 31
                    }, {
                        "balloonText": "Poor",
                        "color": "#cc4748",
                        "endValue": 100,
                        "startValue": 71
                    }],
                "bottomText": "50",
                "bottomTextYOffset": -1,
                "endValue": 100
            }],
        "arrows": [{"value": 50}],
        "export": {
            "enabled": false
        }
    }); 

    var gaugeChart = AmCharts.makeChart("gaugeKritis8", {
        "type": "gauge",
        "theme": "light",
        "axes": [{
                "axisThickness": 1,
                "axisAlpha": 0.2,
                "tickAlpha": 0.2,
                "labelsEnabled": false,
                "bands": [{
                        "balloonText": "Good",
                        "color": "#84b761",
                        "endValue": 30,
                        "startValue": 0
                    }, {
                        "balloonText": "Fair",
                        "color": "#fdd400",
                        "endValue": 70,
                        "startValue": 31
                    }, {
                        "balloonText": "Poor",
                        "color": "#cc4748",
                        "endValue": 100,
                        "startValue": 71
                    }],
                "bottomText": "50",
                "bottomTextYOffset": -1,
                "endValue": 100
            }],
        "arrows": [{"value": 50}],
        "export": {
            "enabled": false
        }
    });

    var gaugeChart = AmCharts.makeChart("gaugeKritis9", {
        "type": "gauge",
        "theme": "light",
        "axes": [{
                "axisThickness": 1,
                "axisAlpha": 0.2,
                "tickAlpha": 0.2,
                "labelsEnabled": false,
                "bands": [{
                        "balloonText": "Good",
                        "color": "#84b761",
                        "endValue": 30,
                        "startValue": 0
                    }, {
                        "balloonText": "Fair",
                        "color": "#fdd400",
                        "endValue": 70,
                        "startValue": 31
                    }, {
                        "balloonText": "Poor",
                        "color": "#cc4748",
                        "endValue": 100,
                        "startValue": 71
                    }],
                "bottomText": "50",
                "bottomTextYOffset": -1,
                "endValue": 100
            }],
        "arrows": [{"value": 50}],
        "export": {
            "enabled": false
        }
    });

</script>
<script>
    /*function close*/

    $('#close').click(function pass_cek(e) {
        e.preventDefault();
        $('#placeholder').hide();
        $('#profil').hide();
        $('#kontrak').hide();
        $('#posisi').hide();
        $('#status').hide();
        $('#Kendala').hide();
        $("#graph1d").empty();
        $("#graph2d").empty();
        $("#graph3d").empty();
        $("#graph4d").empty();
        $("#graph5d").empty();
        $("#graph6d").empty();
    });

    $('#closeProfil').click(function pass_cek(e) {
        e.preventDefault();
        $('#profil').hide();
    });

    $('#closeKontrak').click(function pass_cek(e) {
        e.preventDefault();
        $('#kontrak').hide();
        // coba(id_branch);
    });

    $('#closeKontrak_awal').click(function pass_cek(e) {
        e.preventDefault();
        $('#kontrak_awal').hide();
        // coba(id_branch);
    });

    $('#closePosisi').click(function pass_cek(e) {
        e.preventDefault();
        $('#posisi').hide();
    });

     $('#closePosisi_awal').click(function pass_cek(e) {
        e.preventDefault();
        $('#posisi_awal').hide();
    });

    $('#closeStatus').click(function pass_cek(e) {
        e.preventDefault();
        $('#status').hide();
    });

    $('#closeStatus_awal').click(function pass_cek(e) {
        e.preventDefault();
        $('#status_awal').hide();
    });

    $('#closeKendala').click(function pass_cek(e) {
        e.preventDefault();
        $('#kendala').hide();
    });

    $('#closeKendala_awal').click(function pass_cek(e) {
        e.preventDefault();
        $('#kendala_awal').hide();
    });

    $('#closeD_status').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_status').hide();
        $('#status').show();
    });

    $('#closeD_kendala').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kendala').hide();
        $('#kendala').show();
    });

    $('#closeD_kendala_awal').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kendala_awal').hide();
        $('#kendala_awal').show();
    });


    function profil(id_branch) {
        $('#profil').show(function(){

            $.ajax({
                url:"<?php echo base_url() ?>home/profil/" + id_branch,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);
                    $('#nama').text(data.data['DISPLAY_NAME']);
                    
                }
            })

        });
        // alert(id_branch);
    }


    /*function menu modal*/
    function print_kontrak(id_branch) {
        $('#kontrak').show(function(){
        window.open("<?php base_url();?>home_print/print_kontrak_kritis/" + id_branch , "_blank");

        });
        // alert(id_branch);
    }

     function print_kontrak_awal(id_branch) {
        $('#kontrak_awal').show(function(){
        window.open("<?php base_url();?>home_print/print_kontrak_kritis_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>" , "_blank");

        });
        // alert(id_branch);
    }

    function kontrak(id_branch) {
       $("#kontrak").modal({
            backdrop: 'static'
        });
       // $('#kontrak').show(function(){

            $('#list_prog_inv').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/kontrak_kritis/" + id_branch,
                    "destroy": "true",
                    "columns": [
                        { "data": "RKAP_INVS_ID" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_INVS_COST_REQ", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_COST_REQ).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_COST_REQ == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REAL_SUBPRO_VAL", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        }
                    ]
                } );

            $.ajax({
                url:"<?php echo base_url() ?>home/kontrak_kritis/" + id_branch,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);
                    $('#nama_cabang').text(data.data2['DISPLAY_NAME']);

                    var data_inves = "";

                    $.each(data.data3, function(key, val){

                        var value = parseFloat(val.TDANA).toFixed(2);
                        var set_value = value.replace(".", ",");

                        var value2 = parseFloat(val.TRKAP).toFixed(2);
                        var set_value2 = value2.replace(".", ",");

                        var value3 = parseFloat(val.TREALISASI).toFixed(2);
                        var set_value3 = value3.replace(".", ",");

                        data_inves += "<tr>\
                        <td>" + "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        <td>" + "Rp. "+set_value2.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        <td>" + "Rp. "+set_value3.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        </tr>";

                    });
                    
                    $('#show_investasi').html(data_inves);
                }
            })

        //});
        // alert(id_branch);
    }

    function kontrak_awal(id_branch) {
        //$('#kontrak_awal').show(function(){
        $("#kontrak_awal").modal({
            backdrop: 'static'
        });
        
             $('#list_prog_inv_awal').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/kontrak_kritis_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>",
                    "destroy": "true",
                    "columns": [
                        { "data": "RKAP_INVS_ID" },
                        
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_INVS_COST_REQ", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_COST_REQ).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_COST_REQ == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REAL_SUBPRO_VAL", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "RKAP_INVS_ID",
                            "render": function(data, type, row) {
                            id_status1 = row.RKAP_INVS_ID;
                            return '<button class="btn btn-success btn-xs" onclick="window.open(\'<?php echo base_url();?>rkapinvestasi/detail/'+id_status1+'\')"><i class="icon md-arrow-right"></i></button>'; }    
                        }
                    ]
                } );

            $.ajax({
                url:"<?php echo base_url() ?>home/kontrak_kritis_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>",
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);

                    var data_inves = "";

                    $.each(data.data3, function(key, val){

                        var value = parseFloat(val.TDANA).toFixed(2);
                        var set_value = value.replace(".", ",");

                        var value2 = parseFloat(val.TRKAP).toFixed(2);
                        var set_value2 = value2.replace(".", ",");

                        var value3 = parseFloat(val.TREALISASI).toFixed(2);
                        var set_value3 = value3.replace(".", ",");

                        data_inves += "<tr>\
                        <td>" + "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        <td>" + "Rp. "+set_value2.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        <td>" + "Rp. "+set_value3.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        </tr>";

                    });
                    
                    $('#show_investasi_awal').html(data_inves);

                    // $.each(data.data, function(key, val){

                    //     var value = parseFloat(val.RKAP_INVS_COST_REQ).toFixed(2);
                    //     var set_value = value.replace(".", ",");

                    //     var value2 = parseFloat(val.RKAP_INVS_VALUE).toFixed(2);
                    //     var set_value2 = value2.replace(".", ",");

                    //     $.each(data.data4, function(key,list){
                    //     // console.log(list)
                    //     // console.log(val.RKAP_INVS_ID)
                    //         if (list.RKAP_SUBPRO_INVS_ID == val.RKAP_INVS_ID) {
                    //             realisasi = list.REAL_SUBPRO_VAL
                    //         } 
                            
                    //     });

                    //     data += "<tr>\
                    //     <td>" + val.RKAP_INVS_ID + "</td>\
                    //     <td>" + val.RKAP_INVS_TITLE + "</td>\
                    //     <td>" + "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                    //     <td>" + "Rp. "+set_value2.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                    //     </tr>";

                    // });
                    
                    // $('#show_test').html(data);
                }
            })

        //});
        // alert(id_branch);
    }

    function posisi(id_branch) {
         $("#posisi").modal({
            backdrop: 'static'
         });
        //$('#posisi').show(function(){

            $.ajax({
                url:"<?php echo base_url() ?>home/list_investasi_posisi/" + id_branch,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);

                    /*dropdown*/
                    var d_posisi = "";

                    $.each(data.data3, function(key, val){
                        d_posisi += '<option value='+val.POSPROG_ID+'>' + val.POSPROG_NAME + '</option>';

                    });
                    
                    $('#show_d_posisi').html(d_posisi);
                }
            })

        //});
        // alert(id_branch);
    }

    function posisi_awal(id_branch) {
       // $('#posisi_awal').show(function(){
            $("#posisi_awal").modal({
                backdrop: 'static'
            });
         
            $.ajax({
                url:"<?php echo base_url() ?>home/list_investasi_posisi_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>",
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);

                    /*dropdown*/
                    var d_posisi = "";

                    $.each(data.data3, function(key, val){
                        d_posisi += '<option value='+val.POSPROG_ID+'>' + val.POSPROG_NAME + '</option>';

                    });
                    
                    $('#show_d_posisi_awal').html(d_posisi);
                }
            })

        //});
        // alert(id_branch);
    }

    function status(id_branch) {
        $("#status").modal({
            backdrop: 'static'
        });
        
        //$('#status').show(function(){

            $.ajax({
                url:"<?php echo base_url() ?>home/list_investasi_status/" + id_branch,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);

                    /*dropdown*/
                    var d_status = "";

                    $.each(data.data3, function(key, val){
                        d_status += '<option value='+val.IS_RESULT+'>' + val.STATUS_NAME + '</option>';

                    });
                    
                    // value="val.STATUS_NAME"
                    $('#show_d_status').html(d_status);
                }
            })

       // });
        // alert(d_status);
    }

    function status_awal(id_branch) {
        //$('#status_awal').show(function(){
            $("#status_awal").modal({
                backdrop: 'static'
            });
        
            $.ajax({
                url:"<?php echo base_url() ?>home/list_investasi_status_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>",
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);

                    /*dropdown*/
                    var d_status = "";

                    $.each(data.data3, function(key, val){
                        d_status += '<option value='+val.IS_RESULT+'>' + val.STATUS_NAME + '</option>';

                    });
                    
                    // value="val.STATUS_NAME"
                    $('#show_d_status_awal').html(d_status);
                }
            })

        //});
        // alert(d_status);
    }

    function kendala(id_branch) {
       // $('#kendala').show(function(){
             $("#kendala").modal({
                backdrop: 'static'
            });
            $.ajax({
                url:"<?php echo base_url() ?>home/list_investasi_kendala/" + id_branch,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);

                    /*dropdown*/
                    var d_kendala = "";

                    $.each(data.data3, function(key, val){
                        d_kendala += '<option value='+val.CONTRAINTS_ID+'>' + val.CONTRAINTS_NAME + '</option>';

                    });
                    
                    $('#show_d_kendala').html(d_kendala);
                }
            })

        //});
        // alert(id_branch);
    }

    function kendala_awal(id_branch) {
       // $('#kendala_awal').show(function(){
             $("#kendala_awal").modal({
                backdrop: 'static'
            });
            
            $.ajax({
                url:"<?php echo base_url() ?>home/list_investasi_kendala_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>",
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);

                    /*dropdown*/
                    var d_kendala = "";

                    $.each(data.data3, function(key, val){
                        d_kendala += '<option value='+val.CONTRAINTS_ID+'>' + val.CONTRAINTS_NAME + '</option>';

                    });
                    
                    $('#show_d_kendala_awal').html(d_kendala);
                }
            })

       // });
        // alert(id_branch);
    }

    /*function search ajax*/

    function print_status (){
        var status = $('#show_d_status').val();
        window.open("<?php base_url();?>home_print/print_investasi_status/" + id_branch +"/"+status , "_blank");
        // alert (status)
        
    }

    function print_status_awal (){
        var status = $('#show_d_status_awal').val();
        window.open("<?php base_url();?>home_print/print_investasi_status_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>/"+status , "_blank");
        // alert (status)
        
    }
    
    function cari_status (){
        var status = $('#show_d_status').val()
        // alert (status)
            $('#list_status').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/list_investasi_status/" + id_branch +"/"+status,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "REAL_SUBPRO_STATUS" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REAL_SUBPRO_VAL", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "BRANCH_ID",
                            "render": function(data, type, row) {
                            id_status = row.BRANCH_ID;
                                return '<button class="btn btn-success btn-sm" onclick="detail_status(\''+id_status+'\')">' + 'Detail' + '</button>'; }
                        }
                    ]
                } );

            $.ajax({
                url:"<?php echo base_url() ?>home/list_investasi_status/" + id_branch +"/"+status,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);
                    $('#nama_cabang3').text(data.data2['DISPLAY_NAME']);
                }
            })
    }

     function cari_status_awal (){
        var status = $('#show_d_status_awal').val()

            $('#list_status_awal').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/list_investasi_status_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>/"+status,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "REAL_SUBPRO_STATUS" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REAL_SUBPRO_VAL", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "BRANCH_ID",
                            "render": function(data, type, row) {
                            id_status = row.BRANCH_ID;
                                return '<button class="btn btn-success btn-sm" onclick="detail_status_awal(\''+id_status+'\')">' + 'Detail' + '</button>'; }
                        }
                    ]
                } );

        $.ajax({
                url:"<?php echo base_url() ?>home/list_investasi_status_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>/"+status,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);
                    $('#cabang_nama3').text(data.data2['NAME_DISPLAY']);
                }
            })
    }

    function detail_status (id_status){
        var status = $('#show_d_status').val()
        // alert(id_status)
        // $('#status').hide();
        // $('#detail_status').show(function(){
        $("#detail_status").modal({
            backdrop: 'static'
        }); 

            $('#show_detail_status').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/detail_status/" + id_status +"/"+status,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_YEAR" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_INVS_COST_REQ", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_COST_REQ).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_COST_REQ == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REALISASI", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REALISASI).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REALISASI == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "STAT" },
                        
                    ]
                } );

        // });
    }

     function detail_status_awal (id_status){
        var status = $('#show_d_status_awal').val()
        // alert(id_status)
        // $('#status_awal').hide();
        // $('#detail_status_awal').show(function(){
        $("#detail_status_awal").modal({
            backdrop: 'static'
        }); 

            $('#show_detail_status_awal').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/detail_status_awal/" + id_status +"/"+status,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_YEAR" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_INVS_COST_REQ", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_COST_REQ).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_COST_REQ == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REALISASI", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REALISASI).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REALISASI == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "STAT" },
                        
                    ]
                } );

        // });
    }

    function print_posisi (){
        var posisi = $('#show_d_posisi').val()
        window.open("<?php base_url();?>home_print/print_investasi_posisi/" + id_branch +"/"+posisi , "_blank");
        // alert (status)
        
    }

     function print_posisi_awal (){
        var posisi = $('#show_d_posisi_awal').val()
        window.open("<?php base_url();?>home_print/print_investasi_posisi_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>/"+posisi , "_blank");
        // alert (status)
        
    }

   function cari_posisi (){
        var posisi = $('#show_d_posisi').val()

                $('#list_posisi').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/list_investasi_posisi/" + id_branch+"/"+posisi,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_POS" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REAL_SUBPRO_VAL", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "BRANCH_ID",
                            "render": function(data, type, row) {
                            id_posisi = row.BRANCH_ID;
                                return '<button class="btn btn-success btn-sm" onclick="detail_posisi(\''+id_posisi+'\')">' + 'Detail' + '</button>'; }
                        }
                    ]
                } );

       $.ajax({
                url:"<?php echo base_url() ?>home/list_investasi_posisi/" + id_branch+"/"+posisi,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);
                    $('#nama_cabang2').text(data.data2['DISPLAY_NAME']);
                }
            })
    }

    function cari_posisi_awal (){
        var posisi = $('#show_d_posisi_awal').val()
        // alert (posisi)
                $('#list_posisi_awal').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/list_investasi_posisi_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>/"+posisi,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_POS" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REAL_SUBPRO_VAL", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "BRANCH_ID",
                            "render": function(data, type, row) {
                            id_posisi = row.BRANCH_ID;
                                return '<button class="btn btn-success btn-sm" onclick="detail_posisi_awal(\''+id_posisi+'\')">' + 'Detail' + '</button>'; }
                        }
                    ]
                } );

       $.ajax({
                url:"<?php echo base_url() ?>home/list_investasi_posisi_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>/"+posisi,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);
                    $('#cabang_nama2').text(data.data2['NAME_DISPLAY']);
                }
            })
    }

    function detail_posisi (id_posisi){
        var posisi = $('#show_d_posisi').val()
        // alert(id_status)
        // $('#posisi').hide();
        // $('#detail_posisi').show(function(){
        $("#detail_posisi").modal({
            backdrop: 'static'
        }); 

            $('#show_detail_posisi').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/detail_posisi/" + id_posisi +"/"+posisi,
                    "destroy": "true",
                    "columns": [
                        // { "data": "BRANCH_NAME" },
                        // { "data": "RKAP_INVS_ID" },
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_INVS_COST_REQ", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_COST_REQ).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_COST_REQ == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "POSPROG_NAME" }
                    ]
                } );

        // });
    }

    function detail_posisi_awal (id_posisi){
        var posisi = $('#show_d_posisi_awal').val()
        // alert(id_status)
        // $('#posisi_awal').hide();
        // $('#detail_posisi_awal').show(function(){
        $("#detail_posisi_awal").modal({
            backdrop: 'static'
        }); 

            $('#show_detail_posisi_awal').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/detail_posisi_awal/" + id_posisi +"/"+posisi,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_INVS_COST_REQ", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_COST_REQ).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_COST_REQ == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "POSPROG_NAME" }
                    ]
                } );

        // });
    }

     function print_kendala (){
        var kendala = $('#show_d_kendala').val();
        window.open("<?php base_url();?>home_print/print_investasi_kendala/" + id_branch +"/"+kendala , "_blank");
    }

    function print_kendala_awal (){
        var kendala = $('#show_d_kendala_awal').val();
        window.open("<?php base_url();?>home_print/print_investasi_kendala_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>/"+kendala , "_blank");
    }

    function cari_kendala (){
        var kendala = $('#show_d_kendala').val()
        // alert (kendala)
            $('#list_kendala').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/list_investasi_kendala/" + id_branch+"/"+kendala,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "REAL_SUBPRO_CONSTRAINTS" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REAL_SUBPRO_VAL", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "BRANCH_ID",
                            "render": function(data, type, row) {
                            id_kendala = row.BRANCH_ID;
                                return '<button class="btn btn-success btn-sm" onclick="detail_kendala(\''+id_kendala+'\')">' + 'Detail' + '</button>'; }
                        }
                    ]
                } );

            $.ajax({
                url:"<?php echo base_url() ?>home/list_investasi_kendala/" + id_branch+"/"+kendala,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);
                    $('#nama_cabang4').text(data.data2['DISPLAY_NAME']);
                }
            })
    }

    function cari_kendala_awal (){
        var kendala = $('#show_d_kendala_awal').val()

                $('#list_kendala_awal').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/list_investasi_kendala_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>/"+kendala,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "REAL_SUBPRO_CONSTRAINTS" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REAL_SUBPRO_VAL", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "BRANCH_ID",
                            "render": function(data, type, row) {
                            id_kendala = row.BRANCH_ID;
                                return '<button class="btn btn-success btn-sm" onclick="detail_kendala_awal(\''+id_kendala+'\')">' + 'Detail' + '</button>'; }
                        }
                    ]
                } );

             $.ajax({
                url:"<?php echo base_url() ?>home/list_investasi_kendala_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>/"+kendala,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);
                    $('#cabang_nama4').text(data.data2['NAME_DISPLAY']);
                }
            })
    }

    function detail_kendala (id_kendala){
        var kendala = $('#show_d_kendala').val()
        // alert(id_kendala)
        // $('#kendala').hide();
        // $('#detail_kendala').show(function(){
        $("#detail_kendala").modal({
            backdrop: 'static'
        }); 

            $('#show_detail_kendala').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/detail_kendala/" + id_kendala+"/"+kendala,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_YEAR" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "TOTAL" },
                        { "data": "CONTRAINTS_NAME" }
                    ]
                } );

        // });
    }

    function detail_kendala_awal (id_kendala){
        var kendala = $('#show_d_kendala_awal').val()
        // alert(id_kendala)
        // $('#kendala_awal').hide();
        // $('#detail_kendala_awal').show(function(){
        $("#detail_kendala_awal").modal({
            backdrop: 'static'
        }); 

            $('#show_detail_kendala_awal').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/detail_kendala_awal/" + id_kendala+"/"+kendala,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_YEAR" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "TOTAL", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.TOTAL).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.TOTAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "CONTRAINTS_NAME" }
                    ]
                });

        // });
    }

    
</script>

<script>
    
    // function pusat() {
        // alert(<?php echo $this->session->userdata('SESS_USER_PRIV') ?>);
        var login_priv = <?php echo $this->session->userdata('SESS_USER_PRIV') ?>;
       
        if (login_priv == 1) {
            $('#modal_all').show(function(){
            // alert(is_pusat)
            $.ajax({
                url:"<?php echo base_url() ?>home/detail_all/",
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);
                    $('#value_fisik_all').text(data.data13['REAL_SUBPRO_VAL']);
                    $('#value_program_all').text(data.data3['JML1'] + ' Program Berjalan');

                    var value = parseFloat(data.data15['VALUE_REALISASI']).toFixed(2);
                    var set_value = value.replace(".", ",");
                    var fix_value = "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");

                    $('#value_realisasi_all').text(fix_value);

                    var get_realisasi = parseFloat(data.data2['REALISASI_FISIK']).toFixed(2);
                    var realisasi = get_realisasi.replace(".", ",");

                    var get_program = parseFloat(data.data3['KPI_REALISASI_PROGRAM']).toFixed(2);
                    var program = get_program.replace(".", ",");

                    var get_fisik = parseFloat(data.data4['KPI_REALISASI_FISIK']).toFixed(2);
                    var fisik = get_fisik.replace(".", ",");

                    var good = data.data12['ABC'] / 3;
                    var fair = good * 2;
                    var poor = good * 3;

                    /*Status Program Investasi*/
                    var gaugeChart = AmCharts.makeChart("all_pieDetails4", {
                        "type": "pie",
                        "pullOutRadius": 0,
                        "labelRadius": 0,
                        "radius": "35%",
                        "dataProvider": [{
                                "category": "Berjalan",
                                "color": "#009688",
                                "value": data.data3['JML1']
                            }, {
                                "category": "Belum Berjalan",
                                "color": "#EF4423",
                                "value": data.data3['BELUMBERJALAN']
                            }],
                            "labelText": "",
                            "colorField": "color",
                            "valueField": "value",
                        "titleField": "category"
                    });


                    //konsolidasi yayan-gauge

                    //all realisasi fisik
                    var dt111 = parseFloat(data.data2['REALISASI_FISIK']).toFixed(2);
                    var dt222 = 100-dt111;
                    var donut111 = Morris.Donut({
                        element: 'graph111',
                        data: [
                            {label: data.data2['RE'], value: dt111},
                            {label: '', value: dt222}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#009688',
                            '#ff3d00',
                        ],
                        formatter: function (x) { return x + "%"}
                        });
                    
                    // all program berjalan
                    var dt333 = parseFloat(data.data3['JML1'] / data.data3['JML2'] * 100).toFixed(2);
                    var dt444 = 100 - dt333;
                    var donut222 = Morris.Donut({
                        element: 'graph222',
                        data: [
                            {value: dt333, label: data.data3['JML1']+"/"+data.data3['JML2']},
                            {value: dt444, label: data.data3['JML1']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#009688',
                            '#ff3d00',
                        ],
                        formatter: function (x) { return x + "%"}
                        });
                    
                    //all kpi realisasi fisik
                    var dt555 = parseFloat(data.data4['KPI_REALISASI_FISIK']).toFixed(2);
                    var dt666 = 100 - dt555;
                    var donut111 = Morris.Donut({
                        element: 'graph333',
                        data: [
                            {value: dt555, label: data.data2['RE']},
                            {value: dt666, label: data.data2['RE']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#009688',
                            '#ff3d00',
                        ],
                        formatter: function (x) { return x + "%"}
                        });
                    
                    
                    // all kontrak kritis 1
                    var kk111 = parseFloat(data.data9['DEVIASI'] / data.data12['ABC'] * 100).toFixed(2);
                    var kk222 = 100 - kk111;
                    var donut444 = Morris.Donut({
                        element: 'graph444',
                        data: [
                            {value: kk111, label: data.data9['DEVIASI']+"/"+data.data12['ABC']},
                            {value: kk222, label: data.data9['DEVIASI']+"/"+data.data12['ABC']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#ff3d00',
                            '#009688'
                        ],
                        formatter: function (x) { return x + "%"}
                        });
                    
                    // all kontrak kritis 2
                    var kk333 = parseFloat(data.data10['DEVIASI'] / data.data12['ABC'] * 100).toFixed(2);
                    var kk444 = 100 - kk111;
                    var donut555 = Morris.Donut({
                        element: 'graph555',
                        data: [
                            {value: kk333, label: data.data10['DEVIASI']+"/"+data.data12['ABC']},
                            {value: kk444, label: data.data10['DEVIASI']+"/"+data.data12['ABC']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#ff3d00',
                            '#009688'
                        ],
                        formatter: function (x) { return x + "%"}
                        });
                    
                    // all kontrak kritis 3
                    var kk555 = parseFloat(data.data11['DEVIASI'] / data.data12['ABC'] * 100).toFixed(2);
                    var kk666 = 100 - kk111;
                    var donut666 = Morris.Donut({
                        element: 'graph666',
                        data: [
                            {value: kk555, label: data.data11['DEVIASI']+"/"+data.data12['ABC']},
                            {value: kk666, label: data.data11['DEVIASI']+"/"+data.data12['ABC']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#ff3d00',
                            '#009688'
                        ],
                        formatter: function (x) { return x + "%"}
                        });

                    /*Posisi*/
                    var data_posisi_pusat = [];

                    $.each(data.data7, function(key, val){

                        if (val.RKAP_INVS_POS == 1)
                            var color = "#FF0F00";
                        else if (val.RKAP_INVS_POS == 2)
                            var color = "#FF6600";
                        else if (val.RKAP_INVS_POS == 3)
                            var color = "#FF9E01";
                        else if (val.RKAP_INVS_POS == 4)
                            var color = "#FCD202";
                        else if (val.RKAP_INVS_POS == 5)
                            var color = "#F8FF01";
                        else if (val.RKAP_INVS_POS == 6)
                            var color = "#B0DE09";
                        else if (val.RKAP_INVS_POS == 7)
                            var color = "#04D215";
                        else if (val.RKAP_INVS_POS == 8)
                            var color = "#0D8ECF";
                        else if (val.RKAP_INVS_POS == 9)
                            var color = "#0D52D1";
                        else if (val.RKAP_INVS_POS == 10)
                            var color = "#2A0CD0";
                        else if (val.RKAP_INVS_POS == 11)
                            var color = "#8A0CCF";
                        else if (val.RKAP_INVS_POS == 12)
                            var color = "#CD0D74";
                        else if (val.RKAP_INVS_POS == 13)
                            var color = "#04D215";

                        data_posisi_pusat.push ( {
                            "country": val.POSISI,
                            "visits": val.JUMLAH_POSISI,
                            "color": color
                        });
                    });

                    var posisi_investasi_all = "";

                    $.each(data.data7, function(key, val){

                        if (val.POSPROG_ID == 1) 
                            var src = "<?php echo base_url(); ?>/assets/flat/charts.png?>";
                        else if (val.POSPROG_ID == 2)
                            var src = "<?php echo base_url(); ?>/assets/flat/statistics2.png?>";
                        else if (val.POSPROG_ID == 3)
                            var src = "<?php echo base_url(); ?>/assets/flat/planning.jpg?>";
                        else if (val.POSPROG_ID == 4)
                            var src = "<?php echo base_url(); ?>/assets/flat/map.png?>";
                        else if (val.POSPROG_ID == 5)
                            var src = "<?php echo base_url(); ?>/assets/flat/job-search.png?>";
                        else if (val.POSPROG_ID == 6)
                            var src = "<?php echo base_url(); ?>/assets/flat/auction.png?>";
                        else if (val.POSPROG_ID == 7)
                            var src = "<?php echo base_url(); ?>/assets/flat/vector.png?>";
                        else if (val.POSPROG_ID == 8)
                            var src = "<?php echo base_url(); ?>/assets/flat/melt.png?>";
                        else if (val.POSPROG_ID == 9)
                            var src = "<?php echo base_url(); ?>/assets/flat/statistics.png?>";
                        else if (val.POSPROG_ID == 10)
                            var src = "<?php echo base_url(); ?>/assets/flat/chronometer.png?>";
                        else if (val.POSPROG_ID == 11)
                            var src = "<?php echo base_url(); ?>/assets/flat/recycling-plant.png?>";
                        else if (val.POSPROG_ID == 12)
                            var src = "<?php echo base_url(); ?>/assets/flat/construction.png?>";
                        else if (val.POSPROG_ID == 13)
                            var src = "<?php echo base_url(); ?>/assets/flat/approve.png?>";

                        posisi_investasi_all += '<li class="list-group-item">\
                            <div class="media" style="border-bottom:1px solid #e5e7ea; padding-bottom : 10px;">\
                                <div class="pr-20">\
                                <a class="avatar-md" href="javascript:void(0)">\
                                    <img class="img-responsive" style="height:45px" src="'+ src +'" alt="...">\
                                </a>\
                                </div>\
                                <div class="media-body">\
                                    <h5 class="mt-0 mb-5">' + val.POSISI + '</h5>\
                                    <p>' + val.JUMLAH_POSISI + '</p>\
                                </div>\
                            </div>\
                        </li>';

                    });
                    
                    $('#posisi_investasi_all').html(posisi_investasi_all);

                    var kendala_investasi_all = "";

                    $.each(data.data8, function(key, val){

                        kendala_investasi_all += '<h5>' + val.CONTRAINTS_NAME + '\
                              <span class="float-right">' + val.TOTAL_KENDALA + '</span>\
                            </h5>\
                            <div class="progress progress-sm">\
                              <div  class="progress-bar bg-info1 active" style="width: ' + val.TOTAL_KENDALA + '%; margin-right:50px !IMPORTANT" role="progressbar"></div>\
                            </div>';

                    });
                    
                    $('#kendala_investasi_all').html(kendala_investasi_all);

                    var chart = AmCharts.makeChart("all_tabung1", {
                        "type": "serial",
                        "theme": "none",
                        // "marginRight": 70,
                        "dataProvider": data_posisi_pusat,
                        "valueAxes": [{
                                "axisAlpha": 0,
                                "position": "left",
                                "title": "jumlah"
                            }],
                        "startDuration": 1,
                        "graphs": [{
                                "balloonText": "<b>[[category]]: [[value]]</b>",
                                "fillColorsField": "color",
                                "fillAlphas": 0.9,
                                "lineAlpha": 0.2,
                                "type": "column",
                                "valueField": "visits"
                            }],
                        "chartCursor": {
                            "categoryBalloonEnabled": false,
                            "cursorAlpha": 0,
                            "zoomable": false
                        },
                        "categoryField": "country",
                        "categoryAxis": {
                            "gridPosition": "start",
                            "labelRotation": 45
                        },
                        "export": {
                            "enabled": false
                        }

                    });

                    /*Kendala*/
                    var data_kendala = [];

                    $.each(data.data8, function(key, val){

                        if (val.REAL_SUBPRO_CONSTRAINTS == 1)
                            var color = "#FF0F00";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 2)
                            var color = "#FF6600";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 3)
                            var color = "#FF9E01";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 4)
                            var color = "#FCD202";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 5)
                            var color = "#F8FF01";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 6)
                            var color = "#B0DE09";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 7)
                            var color = "#04D215";

                        data_kendala.push ( {
                            "country": val.CONTRAINTS_NAME,
                            "visits": val.TOTAL_KENDALA,
                            "color": color
                        });
                    });

                    var chart = AmCharts.makeChart("all_tabung2", {
                        "type": "serial",
                        "theme": "none",
                        // "marginRight": 100,
                        "dataProvider": data_kendala,
                        "valueAxes": [{
                                "axisAlpha": 0,
                                "position": "left",
                                "title": "jumlah"
                            }],
                        "startDuration": 1,
                        "graphs": [{
                                "balloonText": "<b>[[category]]: [[value]]</b>",
                                "fillColorsField": "color",
                                "fillAlphas": 0.9,
                                "lineAlpha": 0.2,
                                "type": "column",
                                "valueField": "visits"
                            }],
                        "chartCursor": {
                            "categoryBalloonEnabled": false,
                            "cursorAlpha": 0,
                            "zoomable": false
                        },
                        "categoryField": "country",
                        "categoryAxis": {
                            "gridPosition": "start",
                            "labelRotation": 45
                        },
                        "export": {
                            "enabled": false
                        }

                    });

                }
            })

            
            });

        }else{
           
            $('#placeholder_awal').show(function(){
                $.ajax({
                    url:"<?php echo base_url() ?>home/detail_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>" ,
                    success(res){
                        var data = JSON.parse(res);
                        //console.log(data);
                        $('#cabangawal').text(data.data['NAME_DISPLAY']);
                        $('#realisasi_fisik').text(data.data2['REALISASI_FISIK']);
                        $('#value_program_awal').text(data.data3['JML1'] + ' Program Berjalan');

                        var value = parseFloat(data.data15['VALUE_REALISASI']).toFixed(2);
                        var set_value = value.replace(".", ",");
                        var fix_value = "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");

                        $('#value_realisasi_awal').text(fix_value);

                        var get_realisasi = parseFloat(data.data2['REALISASI_FISIK']).toFixed(2);
                        var realisasi = get_realisasi.replace(".", ",");

                        var get_program = parseFloat(data.data3['KPI_REALISASI_PROGRAM']).toFixed(2);
                        var program = get_program.replace(".", ",");

                        var get_fisik = parseFloat(data.data4['KPI_REALISASI_FISIK']).toFixed(2);
                        var fisik = get_fisik.replace(".", ",");


                        //awal yayan-gauge

                        //awal realisasi fisik
                        var dt1 = parseFloat(data.data2['REALISASI_FISIK']).toFixed(2);
                        var dt2;
                        if (dt1 < 100) {
                            dt2 = 100 - dt1;
                        }else{
                            dt2 = 0;
                        }
                        var donut1 = Morris.Donut({
                        element: 'graph1',
                        data: [
                            {label: data.data2['RE'], value: dt1},
                            {label: data.data2['RE'], value: dt2}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#009688',
                            '#ff3d00',
                        ],
                        formatter: function (x) { return x + "%"}
                        });
                        
                        //awal program berjalan
                        if (data.data3['JML1'] != 0) {
                            var dt3 = parseFloat(data.data3['JML1'] / data.data3['JML2'] * 100).toFixed(2);
                        }else{
                            var dt3 = 0;
                        }

                        var dt4 = 100 - dt3;
                        var donut2 = Morris.Donut({
                        element: 'graph2',
                        data: [
                            {value: dt3, label: data.data3['JML1']+"/"+data.data3['JML2']},
                            {value: dt4, label: data.data3['JML1']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#009688',
                            '#ff3d00',
                        ],
                        formatter: function (x) { return x + "%"}
                        });
                        
                        //awal kpi realisasi fisik
                        var dt5 = parseFloat(data.data4['KPI_REALISASI_FISIK']).toFixed(2);
                        var dt6;
                        if (dt5 < 100) {
                            dt6 = 100 - dt5;
                        }else{
                            dt6 = 0;
                        }
                        var donut3 = Morris.Donut({
                        element: 'graph3',
                        data: [
                            {value: dt5, label: data.data4['RE']},
                            {value: dt6, label: data.data4['RE']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#009688',
                            '#ff3d00',
                        ],
                        formatter: function (x) { return x + "%"}
                        });

                        /*awal Status Program Investasi*/
                        var gaugeChart = AmCharts.makeChart("pieDetails4awal", {
                            "type": "pie",
                            "pullOutRadius": 0,
                            "labelRadius": 0,
                            "radius": "40%",
                            "dataProvider": [{
                                "category": "Berjalan",
                                "color": "#009688",
                                "value": data.data3['JML1']
                            }, {
                                "category": "Belum Berjalan",
                                "color": "#EF4423",
                                "value": data.data3['BELUMBERJALAN']
                            }],
                            "labelText": "",
                            "colorField": "color",
                            "valueField": "value",
                            "titleField": "category"
                        });
                        
                        /*awal Kendala*/
                        var data_kendala = [];

                        $.each(data.data8, function(key, val){

                            if (val.REAL_SUBPRO_CONSTRAINTS == 1)
                                var color = "#FF0F00";
                            else if (val.REAL_SUBPRO_CONSTRAINTS == 2)
                                var color = "#FF6600";
                            else if (val.REAL_SUBPRO_CONSTRAINTS == 3)
                                var color = "#FF9E01";
                            else if (val.REAL_SUBPRO_CONSTRAINTS == 4)
                                var color = "#FCD202";
                            else if (val.REAL_SUBPRO_CONSTRAINTS == 5)
                                var color = "#F8FF01";
                            else if (val.REAL_SUBPRO_CONSTRAINTS == 6)
                                var color = "#B0DE09";
                            else if (val.REAL_SUBPRO_CONSTRAINTS == 7)
                                var color = "#04D215";

                            data_kendala.push ( {
                                "country": val.CONTRAINTS_NAME,
                                "visits": val.TOTAL_KENDALA,
                                "color": color
                            });
                        });

                        var chart = AmCharts.makeChart("tabung2awal", {
                            "type": "serial",
                            "theme": "none",
                            // "marginRight": 100,
                            "dataProvider": data_kendala,
                            "valueAxes": [{
                                    "axisAlpha": 0,
                                    "position": "left",
                                    "title": "jumlah"
                                }],
                            "startDuration": 1,
                            "graphs": [{
                                    "balloonText": "<b>[[category]]: [[value]]</b>",
                                    "fillColorsField": "color",
                                    "fillAlphas": 0.9,
                                    "lineAlpha": 0.2,
                                    "type": "column",
                                    "valueField": "visits"
                                }],
                            "chartCursor": {
                                "categoryBalloonEnabled": false,
                                "cursorAlpha": 0,
                                "zoomable": false
                            },
                            "categoryField": "country",
                            "categoryAxis": {
                                "gridPosition": "start",
                                "labelRotation": 45
                            },
                            "export": {
                                "enabled": false
                            }

                        });

                        /*awal Posisi*/
                        var data_posisi = [];

                        $.each(data.data7, function(key, val){

                            if (val.RKAP_INVS_POS == 1)
                                var color = "#FF0F00";
                            else if (val.RKAP_INVS_POS == 2)
                                var color = "#FF6600";
                            else if (val.RKAP_INVS_POS == 3)
                                var color = "#FF9E01";
                            else if (val.RKAP_INVS_POS == 4)
                                var color = "#FCD202";
                            else if (val.RKAP_INVS_POS == 5)
                                var color = "#F8FF01";
                            else if (val.RKAP_INVS_POS == 6)
                                var color = "#B0DE09";
                            else if (val.RKAP_INVS_POS == 7)
                                var color = "#04D215";
                            else if (val.RKAP_INVS_POS == 8)
                                var color = "#0D8ECF";
                            else if (val.RKAP_INVS_POS == 9)
                                var color = "#0D52D1";
                            else if (val.RKAP_INVS_POS == 10)
                                var color = "#2A0CD0";
                            else if (val.RKAP_INVS_POS == 11)
                                var color = "#8A0CCF";
                            else if (val.RKAP_INVS_POS == 12)
                                var color = "#CD0D74";
                            else if (val.RKAP_INVS_POS == 13)
                                var color = "#04D215";

                            data_posisi.push ( {
                                "country": val.POSISI,
                                "visits": val.JUMLAH_POSISI,
                                "color": color
                            });
                        });

                        var posisi_investasi_awal = "";

                            $.each(data.data7, function(key, val){

                                if (val.RKAP_INVS_POS == 1) 
                                    var src = "<?php echo base_url(); ?>/assets/flat/charts.png?>";
                                else if (val.RKAP_INVS_POS == 2)
                                    var src = "<?php echo base_url(); ?>/assets/flat/statistics2.png?>";
                                else if (val.RKAP_INVS_POS == 3)
                                    var src = "<?php echo base_url(); ?>/assets/flat/planning.jpg?>";
                                else if (val.RKAP_INVS_POS == 4)
                                    var src = "<?php echo base_url(); ?>/assets/flat/map.png?>";
                                else if (val.RKAP_INVS_POS == 5)
                                    var src = "<?php echo base_url(); ?>/assets/flat/job-search.png?>";
                                else if (val.RKAP_INVS_POS == 6)
                                    var src = "<?php echo base_url(); ?>/assets/flat/auction.png?>";
                                else if (val.RKAP_INVS_POS == 7)
                                    var src = "<?php echo base_url(); ?>/assets/flat/vector.png?>";
                                else if (val.RKAP_INVS_POS == 8)
                                    var src = "<?php echo base_url(); ?>/assets/flat/melt.png?>";
                                else if (val.RKAP_INVS_POS == 9)
                                    var src = "<?php echo base_url(); ?>/assets/flat/statistics.png?>";
                                else if (val.RKAP_INVS_POS == 10)
                                    var src = "<?php echo base_url(); ?>/assets/flat/chronometer.png?>";
                                else if (val.RKAP_INVS_POS == 11)
                                    var src = "<?php echo base_url(); ?>/assets/flat/recycling-plant.png?>";
                                else if (val.RKAP_INVS_POS == 12)
                                    var src = "<?php echo base_url(); ?>/assets/flat/construction.png?>";
                                else if (val.RKAP_INVS_POS == 13)
                                    var src = "<?php echo base_url(); ?>/assets/flat/approve.png?>";

                                posisi_investasi_awal += '<li class="list-group-item">\
                                    <div class="media" style="border-bottom:1px solid #e5e7ea; padding-bottom : 10px;">\
                                        <div class="pr-20">\
                                        <a class="avatar-md" href="javascript:void(0)">\
                                            <img class="img-responsive" style="height:45px" src="'+ src +'" alt="...">\
                                        </a>\
                                        </div>\
                                        <div class="media-body">\
                                            <h5 class="mt-0 mb-5">' + val.POSISI + '</h5>\
                                            <p>' + val.JUMLAH_POSISI + '</p>\
                                        </div>\
                                    </div>\
                                </li>';

                            });
                            
                            $('#posisi_investasi_awal').html(posisi_investasi_awal);

                            var kendala_investasi_awal = "";

                            $.each(data.data8, function(key, val){

                                kendala_investasi_awal += '<h5>' + val.CONTRAINTS_NAME + '\
                                      <span class="float-right">' + val.TOTAL_KENDALA + '</span>\
                                    </h5>\
                                    <div class="progress progress-sm">\
                                      <div  class="progress-bar bg-info1 active" style="width: ' + val.TOTAL_KENDALA + '%; margin-right:50px !IMPORTANT" role="progressbar"></div>\
                                    </div>';

                            });
                            
                            $('#kendala_investasi_awal').html(kendala_investasi_awal);

                        var chart = AmCharts.makeChart("tabung1awal", {
                            "type": "serial",
                            "theme": "none",
                            // "marginRight": 70,
                            "dataProvider": data_posisi,
                            "valueAxes": [{
                                    "axisAlpha": 0,
                                    "position": "left",
                                    "title": "jumlah"
                                }],
                            "startDuration": 1,
                            "graphs": [{
                                    "balloonText": "<b>[[category]]: [[value]]</b>",
                                    "fillColorsField": "color",
                                    "fillAlphas": 0.9,
                                    "lineAlpha": 0.2,
                                    "type": "column",
                                    "valueField": "visits"
                                }],
                            "chartCursor": {
                                "categoryBalloonEnabled": false,
                                "cursorAlpha": 0,
                                "zoomable": false
                            },
                            "categoryField": "country",
                            "categoryAxis": {
                                "gridPosition": "start",
                                "labelRotation": 45
                            },
                            "export": {
                                "enabled": false
                            }

                        });

                        var good = data.data12['ABC'] / 3;
                        var fair = good * 2;
                        var poor = good * 3;
                        
                        

                        /*awal kontrak kritis 1*/
                        if (data.data12['ABC'] == 0) {
                            var kk1 = 0;    
                        }else{
                            var kk1 = parseFloat(data.data9['DEVIASI'] / data.data12['ABC'] * 100).toFixed(2);
                        }
                        
                        var kk2 = 100 - kk1;
                        var donut4 = Morris.Donut({
                        element: 'graph4',
                        data: [
                            {value: kk1, label: data.data9['DEVIASI']+"/"+data.data12['ABC']},
                            {value: kk2, label: data.data9['DEVIASI']+"/"+data.data12['ABC']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#ff3d00',
                            '#009688'
                        ],
                        formatter: function (x) { return x + "%"}
                        });

                        /*awal kontrak kritis 2*/
                        if (data.data12['ABC'] == 0) {
                            var kk3 = 0;    
                        }else{
                            var kk3 = parseFloat(data.data10['DEVIASI'] / data.data12['ABC'] * 100).toFixed(2);
                        }
                        var kk4 = 100 - kk3;
                        var donut5 = Morris.Donut({
                        element: 'graph5',
                        data: [
                            {value: kk3, label: data.data10['DEVIASI']+"/"+data.data12['ABC']},
                            {value: kk4, label: data.data10['DEVIASI']+"/"+data.data12['ABC']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#ff3d00',
                            '#009688'
                        ],
                        formatter: function (x) { return x + "%"}
                        });


                        /*awal kontrak kritis 3*/
                        if (data.data12['ABC'] == 0) {
                            var kk5 = 0;    
                        }else{
                            var kk5 = parseFloat(data.data11['DEVIASI'] / data.data12['ABC'] * 100).toFixed(2);
                        }
                        var kk6 = 100 - kk5;
                        var donut6 = Morris.Donut({
                        element: 'graph6',
                        data: [
                            {value: kk5, label: data.data11['DEVIASI']+"/"+data.data12['ABC']},
                            {value: kk6, label: data.data11['DEVIASI']+"/"+data.data12['ABC']}
                        ],
                        labels: ['title one', 'title Two'],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#ff3d00',
                            '#009688'
                        ],
                        formatter: function (x) { return x + "%"}
                        });


                    }
                })

                
            });
        }
    $('#close_all').click(function pass_cek(e) {
        e.preventDefault();
        $('#modal_all').hide();
    });
    $('#close_place_awal').click(function pass_cek(e) {
        e.preventDefault();
        $('#placeholder_awal').hide();
    });

</script>

<!-- pusat -->
<script>
    // var is_pusat = $('#induk').val();
        
    function induk(is_pusat) {
    // alert(is_pusat)
        var id_name_p = $('#induk').val();
        // alert(id_name_p);
        if (id_name_p != 0) {
            $("#name_perusahaan").html('Dashboard Anak Perusahaan');
        }
        else{
            $("#name_perusahaan").html('Dashboard Perusahaan Induk');
        }
        
        $('#modal_all').hide();
        $('#modal_pusat').hide();
        $('#modal_pusat').show(function(){
            // alert(is_pusat)
            $.ajax({
                url:"<?php echo base_url() ?>home/pusat_detail/" + is_pusat,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);
                    $('#value_fisik_p').text(data.data13['REAL_SUBPRO_VAL']);
                    $('#value_program_pusat').text(data.data3['JML1'] + ' Program Berjalan');

                    var value = parseFloat(data.data15['VALUE_REALISASI']).toFixed(2);
                    var set_value = value.replace(".", ",");
                    var fix_value = "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
                    console.log(fix_value)
                    $('#value_realisasi_pusat').text(fix_value);

                    var get_realisasi = parseFloat(data.data2['REALISASI_FISIK']).toFixed(2);
                    var realisasi = get_realisasi.replace(".", ",");

                    var get_program = parseFloat(data.data3['KPI_REALISASI_PROGRAM']).toFixed(2);
                    var program = get_program.replace(".", ",");

                    var get_fisik = parseFloat(data.data4['KPI_REALISASI_FISIK']).toFixed(2);
                    var fisik = get_fisik.replace(".", ",");
                    
                    //yayan-gauge pusat

                    //pusat realisasi fisik
                    var dt11 = parseFloat(data.data2['REALISASI_FISIK']).toFixed(2);
                    var dt22 = 100-dt11;
                    var donut11 = Morris.Donut({
                        element: 'graph11',
                        data: [
                            {label: data.data2['RE'], value: dt11},
                            {label: '', value: dt22}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#009688',
                            '#ff3d00',
                        ],
                        formatter: function (x) { return x + "%"}
                        });
                    
                    //pusat program berjalan
                    var dt33 = parseFloat(data.data3['JML1'] / data.data3['JML2'] * 100).toFixed(2);
                    var dt44 = 100 - dt33;
                    var donut22 = Morris.Donut({
                        element: 'graph22',
                        data: [
                            {value: dt33, label: data.data3['JML1']+"/"+data.data3['JML2']},
                            {value: dt44, label: data.data3['JML1']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#009688',
                            '#ff3d00',
                        ],
                        formatter: function (x) { return x + "%"}
                        });
                    
                    //awal kpi realisasi fisik
                    var dt55 = parseFloat(data.data4['KPI_REALISASI_FISIK']).toFixed(2);
                    var dt66 = 100 - dt55;
                    var donut33 = Morris.Donut({
                        element: 'graph33',
                        data: [
                            {value: dt55, label: data.data2['RE']},
                            {value: dt66, label: data.data2['RE']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#009688',
                            '#ff3d00',
                        ],
                        formatter: function (x) { return x + "%"}
                        });

                    /*Status Program Investasi*/
                    var gaugeChart = AmCharts.makeChart("p_pieDetails4", {
                        "type": "pie",
                        "pullOutRadius": 0,
                        "labelRadius": 0,
                        "radius": "35%",
                        "dataProvider": [{
                                "category": "Berjalan",
                                "color": "#009688",
                                "value": data.data3['JML1']
                            }, {
                                "category": "Belum Berjalan",
                                "color": "#EF4423",
                                "value": data.data3['BELUMBERJALAN']
                            }],
                            "labelText": "",
                            "colorField": "color",
                            "valueField": "value",
                        "titleField": "category"
                    });


                    /*Posisi*/
                    var data_posisi_pusat = [];

                    $.each(data.data7, function(key, val){

                        if (val.RKAP_INVS_POS == 1)
                            var color = "#FF0F00";
                        else if (val.RKAP_INVS_POS == 2)
                            var color = "#FF6600";
                        else if (val.RKAP_INVS_POS == 3)
                            var color = "#FF9E01";
                        else if (val.RKAP_INVS_POS == 4)
                            var color = "#FCD202";
                        else if (val.RKAP_INVS_POS == 5)
                            var color = "#F8FF01";
                        else if (val.RKAP_INVS_POS == 6)
                            var color = "#B0DE09";
                        else if (val.RKAP_INVS_POS == 7)
                            var color = "#04D215";
                        else if (val.RKAP_INVS_POS == 8)
                            var color = "#0D8ECF";
                        else if (val.RKAP_INVS_POS == 9)
                            var color = "#0D52D1";
                        else if (val.RKAP_INVS_POS == 10)
                            var color = "#2A0CD0";
                        else if (val.RKAP_INVS_POS == 11)
                            var color = "#8A0CCF";
                        else if (val.RKAP_INVS_POS == 12)
                            var color = "#CD0D74";
                        else if (val.RKAP_INVS_POS == 13)
                            var color = "#04D215";

                        data_posisi_pusat.push ( {
                            "country": val.POSISI,
                            "visits": val.JUMLAH_POSISI,
                            "color": color
                        });
                    });
                    var posisi_investasi_pusat = "";

                            $.each(data.data7, function(key, val){
                                if (val.RKAP_INVS_POS == 1) 
                                    var src = "<?php echo base_url(); ?>/assets/flat/charts.png?>";
                                else if (val.RKAP_INVS_POS == 2)
                                    var src = "<?php echo base_url(); ?>/assets/flat/statistics2.png?>";
                                else if (val.RKAP_INVS_POS == 3)
                                    var src = "<?php echo base_url(); ?>/assets/flat/planning.jpg?>";
                                else if (val.RKAP_INVS_POS == 4)
                                    var src = "<?php echo base_url(); ?>/assets/flat/map.png?>";
                                else if (val.RKAP_INVS_POS == 5)
                                    var src = "<?php echo base_url(); ?>/assets/flat/job-search.png?>";
                                else if (val.RKAP_INVS_POS == 6)
                                    var src = "<?php echo base_url(); ?>/assets/flat/auction.png?>";
                                else if (val.RKAP_INVS_POS == 7)
                                    var src = "<?php echo base_url(); ?>/assets/flat/vector.png?>";
                                else if (val.RKAP_INVS_POS == 8)
                                    var src = "<?php echo base_url(); ?>/assets/flat/melt.png?>";
                                else if (val.RKAP_INVS_POS == 9)
                                    var src = "<?php echo base_url(); ?>/assets/flat/statistics.png?>";
                                else if (val.RKAP_INVS_POS == 10)
                                    var src = "<?php echo base_url(); ?>/assets/flat/chronometer.png?>";
                                else if (val.RKAP_INVS_POS == 11)
                                    var src = "<?php echo base_url(); ?>/assets/flat/recycling-plant.png?>";
                                else if (val.RKAP_INVS_POS == 12)
                                    var src = "<?php echo base_url(); ?>/assets/flat/construction.png?>";
                                else if (val.RKAP_INVS_POS == 13)
                                    var src = "<?php echo base_url(); ?>/assets/flat/approve.png?>";

                                posisi_investasi_pusat += '\
                                    <div class="media" style="border-bottom:1px solid #e5e7ea; padding-bottom : 10px;">\
                                        <div class="pr-20">\
                                        <a class="avatar-md" href="javascript:void(0)">\
                                            <img class="img-responsive" style="height:45px" src="'+ src +'" alt="...">\
                                        </a>\
                                        </div>\
                                        <div class="media-body">\
                                            <h5 class="mt-0 mb-5">' + val.POSISI + '</h5>\
                                            <p>' + val.JUMLAH_POSISI + '</p>\
                                        </div>\
                                    </div>\
                                ';

                            });
                            
                            $('#posisi_investasi_pusat').html(posisi_investasi_pusat);

                            var kendala_investasi_pusat = "";

                            $.each(data.data8, function(key, val){

                                kendala_investasi_pusat += '<h5>' + val.CONTRAINTS_NAME + '\
                                      <span class="float-right">' + val.TOTAL_KENDALA + '</span>\
                                    </h5>\
                                    <div class="progress progress-sm">\
                                      <div  class="progress-bar bg-info1 active" style="width: ' + val.TOTAL_KENDALA + '%; margin-right:50px !IMPORTANT" role="progressbar"></div>\
                                    </div>';

                            });
                            
                            $('#kendala_investasi_pusat').html(kendala_investasi_pusat);
                    var chart = AmCharts.makeChart("p_tabung1", {
                        "type": "serial",
                        "theme": "none",
                        // "marginRight": 70,
                        "dataProvider": data_posisi_pusat,
                        "valueAxes": [{
                                "axisAlpha": 0,
                                "position": "left",
                                "title": "jumlah"
                            }],
                        "startDuration": 1,
                        "graphs": [{
                                "balloonText": "<b>[[category]]: [[value]]</b>",
                                "fillColorsField": "color",
                                "fillAlphas": 0.9,
                                "lineAlpha": 0.2,
                                "type": "column",
                                "valueField": "visits"
                            }],
                        "chartCursor": {
                            "categoryBalloonEnabled": false,
                            "cursorAlpha": 0,
                            "zoomable": false
                        },
                        "categoryField": "country",
                        "categoryAxis": {
                            "gridPosition": "start",
                            "labelRotation": 45
                        },
                        "export": {
                            "enabled": false
                        }

                    });

                    /*Kendala*/
                    var data_kendala = [];

                    $.each(data.data8, function(key, val){
                        
                        if (val.REAL_SUBPRO_CONSTRAINTS == 1)
                            var color = "#FF0F00";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 2)
                            var color = "#FF6600";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 3)
                            var color = "#FF9E01";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 4)
                            var color = "#FCD202";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 5)
                            var color = "#F8FF01";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 6)
                            var color = "#B0DE09";
                        else if (val.REAL_SUBPRO_CONSTRAINTS == 7)
                            var color = "#04D215";

                        data_kendala.push ( {
                            "country": val.CONTRAINTS_NAME,
                            "visits": val.TOTAL_KENDALA,
                            "color": color
                        });
                    });

                    console.log(data_kendala)

                    

                    var chart = AmCharts.makeChart("p_tabung2", {
                        "type": "serial",
                        "theme": "none",
                        // "marginRight": 100,
                        "dataProvider": data_kendala,
                        "valueAxes": [{
                                "axisAlpha": 0,
                                "position": "left",
                                "title": "jumlah"
                            }],
                        "startDuration": 1,
                        "graphs": [{
                                "balloonText": "<b>[[category]]: [[value]]</b>",
                                "fillColorsField": "color",
                                "fillAlphas": 0.9,
                                "lineAlpha": 0.2,
                                "type": "column",
                                "valueField": "visits"
                            }],
                        "chartCursor": {
                            "categoryBalloonEnabled": false,
                            "cursorAlpha": 0,
                            "zoomable": false
                        },
                        "categoryField": "country",
                        "categoryAxis": {
                            "gridPosition": "start",
                            "labelRotation": 45
                        },
                        "export": {
                            "enabled": false
                        }

                    });
                    var good = data.data12['ABC'] / 3;
                    var fair = good * 2;
                    var poor = good * 3;



                    
                    /*awal kontrak kritis 1*/
                    var kk11 = parseFloat(data.data9['DEVIASI'] / data.data12['ABC'] * 100).toFixed(2);
                    var kk22 = 100 - kk11;
                    var donut44 = Morris.Donut({
                        element: 'graph44',
                        data: [
                            {value: kk11, label: data.data9['DEVIASI']+"/"+data.data12['ABC']},
                            {value: kk22, label: data.data9['DEVIASI']+"/"+data.data12['ABC']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#ff3d00',
                            '#009688',
                        ],
                        formatter: function (x) { return x + "%"}
                        });
                    
                    /*awal kontrak kritis 2*/
                    var kk33 = parseFloat(data.data10['DEVIASI'] / data.data12['ABC'] * 100).toFixed(2);
                    var kk44 = 100 - kk33;
                    var donut55 = Morris.Donut({
                        element: 'graph55',
                        data: [
                            {value: kk33, label: data.data10['DEVIASI']+"/"+data.data12['ABC']},
                            {value: kk44, label: data.data10['DEVIASI']+"/"+data.data12['ABC']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#ff3d00',
                            '#009688',
                        ],
                        formatter: function (x) { return x + "%"}
                        });
                    
                    // all kontrak kritis 3
                    var kk55 = parseFloat(data.data11['DEVIASI'] / data.data12['ABC'] * 100).toFixed(2);
                    var kk66 = 100 - kk55;
                    var donut66 = Morris.Donut({
                        element: 'graph66',
                        data: [
                            {value: kk55, label: data.data11['DEVIASI']+"/"+data.data12['ABC']},
                            {value: kk66, label: data.data11['DEVIASI']+"/"+data.data12['ABC']}
                        ],
                        resize: true,
                        labelColor: '#060',
                        colors: [
                            '#ff3d00',
                            '#009688',
                        ],
                        formatter: function (x) { return x + "%"}
                        });

                }
            })

            
        });
        // alert(id_branch);
    }

     function print_kontrak_p(is_pusat) {
        $('#kontrak_p').show(function(){
        window.open("<?php base_url();?>home_print/print_pusat_kontrak_kritis/" + is_pusat , "_blank");

        });
        // alert(id_branch);
    }

    /*menu modal pusat*/
    function kontrak_p(is_pusat) {
        $("#kontrak_p").modal({
            backdrop: 'static'
        }); 
        
        //$('#kontrak_p').show(function(){

                $('#list_prog_inv_pusat').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/pusat_kontrak_kritis/" + is_pusat,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_COST_REQ", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_COST_REQ).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_COST_REQ == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REAL_SUBPRO_VAL", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "BRANCH_ID",
                            "render": function(data, type, row) {
                            id_kontrak = row.BRANCH_ID;
                                return '<button class="btn btn-success btn-sm" onclick="detail_kontrak_p(\''+id_kontrak+'\')">' + 'Detail' + '</button>'; }
                        }
                    ]
                } );

                $.ajax({
                url:"<?php echo base_url() ?>home/pusat_kontrak_kritis/" + is_pusat,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);

                    var data_inves = "";

                    $.each(data.data2, function(key, val){

                        var value = parseFloat(val.RKAP_INVS_COST_REQ).toFixed(2);
                        var set_value = value.replace(".", ",");

                        var value2 = parseFloat(val.RKAP_INVS_VALUE).toFixed(2);
                        var set_value2 = value2.replace(".", ",");

                        var value3 = parseFloat(val.REAL_SUBPRO_VAL).toFixed(2);
                        var set_value3 = value3.replace(".", ",");

                        data_inves += "<tr>\
                        <td>" + "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        <td>" + "Rp. "+set_value2.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        <td>" + "Rp. "+set_value3.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        </tr>";

                    });
                    
                    
                    $('#show_inves').html(data_inves);
                }
            })

        //});
        // alert(id_branch);
    }

    function status_p(is_pusat) {
        $("#status_p").modal({
            backdrop: 'static'
        });
        //$('#status_p').show(function(){
            // alert(is_pusat)
            $.ajax({
                url:"<?php echo base_url() ?>home/pusat_list_investasi_status/" + is_pusat,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);

                    /*dropdown*/
                    var d_status = "";

                    $.each(data.data3, function(key, val){
                        d_status += '<option value='+val.IS_RESULT+'>' + val.STATUS_NAME + '</option>';

                    });
                    
                    // value="val.STATUS_NAME"
                    $('#show_d_status_p').html(d_status);
                }
            })

       // });
        // alert(d_status);
    }

    function posisi_p(is_pusat) {
        $("#posisi_p").modal({
            backdrop: 'static'
        });
        //$('#posisi_p').show(function(){

            $.ajax({
                url:"<?php echo base_url() ?>home/pusat_list_investasi_posisi/" + is_pusat,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);

                    /*dropdown*/
                    var d_posisi = "";

                    $.each(data.data3, function(key, val){
                        d_posisi += '<option value='+val.POSPROG_ID+'>' + val.POSPROG_NAME + '</option>';

                    });
                    
                    $('#show_d_posisi_p').html(d_posisi);
                }
            })

        //});
        // alert(id_branch);
    }

    function kendala_p(is_pusat) {
        $("#kendala_p").modal({
            backdrop: 'static'
        });
        
        //$('#kendala_p').show(function(){

            $.ajax({
                url:"<?php echo base_url() ?>home/pusat_list_investasi_kendala/" + is_pusat,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);

                    /*dropdown*/
                    var d_kendala = "";

                    $.each(data.data3, function(key, val){
                        d_kendala += '<option value='+val.CONTRAINTS_ID+'>' + val.CONTRAINTS_NAME + '</option>';

                    });
                    
                    $('#show_d_kendala_p').html(d_kendala);
                }
            })

        //});
        // alert(id_branch);
    }

     function print_cari_status_p (is_pusat){
        var status = $('#show_d_status_p').val()
        window.open("<?php base_url();?>home_print/print_pusat_list_investasi_status/" + is_pusat +"/"+status, "_blank");
        // alert (status)
        
    }

    /*function search modal pusat*/
    function cari_status_p (is_pusat){
        var status = $('#show_d_status_p').val()

                $('#list_status_p').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/pusat_list_investasi_status/" + is_pusat +"/"+status,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "REAL_SUBPRO_STATUS"},
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REAL_SUBPRO_VAL", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REAL_SUBPRO_VAL == null ? '0' : set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "BRANCH_ID",
                            "render": function(data, type, row) {
                            id_status = row.BRANCH_ID;
                                return '<button class="btn btn-success btn-sm" onclick="detail_status_p(\''+id_status+'\')">' + 'Detail' + '</button>'; }
                        }
                    ]
                } );

                $.ajax({
                url:"<?php echo base_url() ?>home/pusat_list_investasi_status/" + is_pusat +"/"+status,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);

                    var data_status = "";

                    $.each(data.data4, function(key, val){

                        var value = parseFloat(val.RKAP_INVS_VALUE).toFixed(2);
                        var set_value = value.replace(".", ",");

                        var value2 = parseFloat(val.REAL_SUBPRO_VAL).toFixed(2);
                        var set_value2 = value2.replace(".", ",");

                        id_status = val.BRANCH_ID;
                        data_status += "<tr>\
                        <td>" + val.REAL_SUBPRO_STATUS + "</td>\
                        <td>" + set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        <td>" + set_value2.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        </tr>";

                    });
                    
                    $('#show_status').html(data_status);
                }
            })
    }

    function detail_status_p (id_status){
        var status = $('#show_d_status_p').val()
        // alert(id_status)
        // $('#status_p').hide();
        // $('#detail_status_p').show(function(){
        $("#detail_status_p").modal({
            backdrop: 'static'
        }); 

            $('#detail_status_ps').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/detail_status_awal/" + id_status +"/"+status,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_YEAR" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_INVS_COST_REQ", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_COST_REQ).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_COST_REQ == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REALISASI", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REALISASI).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REALISASI == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "STAT" },
                        
                    ]
                } );

        // });
    }

    function print_cari_posisi_p (is_pusat){
        var posisi = $('#show_d_posisi_p').val();
         window.open("<?php base_url();?>home_print/print_pusat_list_investasi_posisi/" + is_pusat +"/"+posisi, "_blank");
        // alert (posisi)
      
    }

    function cari_posisi_p (is_pusat){
        var posisi = $('#show_d_posisi_p').val()
        // alert (posisi)
            $('#list_posisi_p').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/pusat_list_investasi_posisi/" + is_pusat+"/"+posisi,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_POS" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REAL_SUBPRO_VAL", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "BRANCH_ID",
                            "render": function(data, type, row) {
                            id_posisi = row.BRANCH_ID;
                                return '<button class="btn btn-success btn-sm" onclick="detail_posisi_p(\''+id_posisi+'\')">' + 'Detail' + '</button>'; }
                        }
                    ]
                } );

            $.ajax({
                url:"<?php echo base_url() ?>home/pusat_list_investasi_posisi/" + is_pusat +"/"+posisi,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);

                    var data_posisi = "";

                    $.each(data.data4, function(key, val){
                        var value = parseFloat(val.RKAP_INVS_VALUE).toFixed(2);
                        var set_value = value.replace(".", ",");

                        var value2 = parseFloat(val.REAL_SUBPRO_VAL).toFixed(2);
                        var set_value2 = value2.replace(".", ",");

                        data_posisi += "<tr>\
                        <td>" + val.RKAP_INVS_POS + "</td>\
                        <td>" + "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        <td>" + "Rp. "+set_value2.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        </tr>";

                    });
                    
                    $('#show_posisi').html(data_posisi);
                }
            })
    }

    function detail_posisi_p (id_posisi){
        var posisi = $('#show_d_posisi_p').val()
        // alert(id_posisi)
        // $('#posisi_p').hide();
        // $('#detail_posisi_p').show(function(){
        $("#detail_posisi_p").modal({
            backdrop: 'static'
        }); 

            $('#detail_posisi_pusat').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/detail_posisi/" + id_posisi +"/"+posisi,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE"},
                        { "data": "RKAP_INVS_COST_REQ", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_COST_REQ).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_COST_REQ == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "POSPROG_NAME"}

                    ]
                } );




        // });
    }

     function print_cari_kendala_p (is_pusat){
        var kendala = $('#show_d_kendala_p').val();
        window.open("<?php base_url();?>home_print/print_pusat_list_investasi_kendala/" + is_pusat +"/"+kendala, "_blank");
        // alert (kendala)
    }

    function cari_kendala_p (is_pusat){
        var kendala = $('#show_d_kendala_p').val()
        // alert (kendala)
                $('#list_kendala_p').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/pusat_list_investasi_kendala/" + is_pusat+"/"+kendala,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "REAL_SUBPRO_CONSTRAINTS" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REAL_SUBPRO_VAL", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "BRANCH_ID",
                            "render": function(data, type, row) {
                            id_kendala = row.BRANCH_ID;
                                return '<button class="btn btn-success btn-sm" onclick="detail_kendala_p(\''+id_kendala+'\')">' + 'Detail' + '</button>'; }
                        }
                    ]
                } );

                $.ajax({
                url:"<?php echo base_url() ?>home/pusat_list_investasi_kendala/" + is_pusat +"/"+kendala,
                success(res){
                    var data = JSON.parse(res);
                    //console.log(data);

                    var data_kendala = "";

                    $.each(data.data4, function(key, val){
                        var value = parseFloat(val.RKAP_INVS_VALUE).toFixed(2);
                        var set_value = value.replace(".", ",");

                        var value2 = parseFloat(val.REAL_SUBPRO_VAL).toFixed(2);
                        var set_value2 = value2.replace(".", ",");

                        data_kendala += "<tr>\
                        <td>" + val.REAL_SUBPRO_CONSTRAINTS + "</td>\
                        <td>" + "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        <td>" + "Rp. "+set_value2.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") + "</td>\
                        </tr>";

                    });
                    
                    $('#show_kendala').html(data_kendala);
                }
            })
      
    }

    function detail_kontrak_p (id_kontrak){
        // $('#kontrak_p').hide();
        // $('#detail_kontrak_p').show(function(){
        $("#detail_kontrak_p").modal({
            backdrop: 'static'
        }); 

                $('#detail_prog_inv').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/detail_kontrak/" + id_kontrak,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_INVS_COST_REQ", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_COST_REQ).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_COST_REQ == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        },
                        { "data": "REAL_SUBPRO_VAL", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                            } 
                        }
                    ]
                } );

        // });
    }

    $('#closeD_kontrak_p').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kontrak_p').hide();
        $('#kontrak_p').show();
    });

    function detail_kendala_p (id_kendala){
        var kendala = $('#show_d_kendala_p').val()
        // alert(id_kendala)
        // $('#kendala_p').hide();
        // $('#detail_kendala_p').show(function(){
        $("#detail_kendala_p").modal({
            backdrop: 'static'
        }); 

            $('#detail_kendala_pusat').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/detail_kendala/" + id_kendala+"/"+kendala,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_YEAR" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "TOTAL" },
                        { "data": "CONTRAINTS_NAME" }
                    ]
                } );

        // });
    }

    //DETAIL GAUGE KRITIS
    function kritis_p(is_pusat) {
        // alert(is_pusat)
        //$('#detail_kritis_1_p').show(function(){
            $("#detail_kritis_1_p").modal({
                backdrop: 'static'
            });
            $('#show_detail_kritis_1_p').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/d_gauge_kritis_1_p/" + is_pusat,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");

                                var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                                var set_value2 = value.replace(".", ",");

                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value3 = value.replace(".", ",");
                                // return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                                return '<div style="color:#090; font-weight:500;font-size:11px" >\
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai RKAP :'+ (row.RKAP_INVS_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Kontrak :'+ (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value2.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Realisasi :'+ (row.REAL_SUBPRO_VAL == null ? '0' : set_value3.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span> \
                                </div>'
                            } 
                        },
                        // { "data": "RKAP_SUBPRO_CONTRACT_VALUE", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                        //     } 
                        // },
                        // { "data": "REAL_SUBPRO_VAL", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                        //     } 
                        // },
                        { "data": "DEVIASI", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.DEVIASI).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.DEVIASI == null ? '0' : set_value.replace()+'%')
                            } 
                        },
                        { "data": "RKAP_SUBPRO_ID",
                            "render": function(data, type, row) {
                            id_subpro = row.RKAP_SUBPRO_ID;
                            return '<button class="btn btn-success btn-xs" onclick="window.open(\'<?php echo base_url() ?>subprogramrkapinvestasi/detail/'+id_subpro+'\')">' + '<i class="icon md-arrow-right"></i>' + '</button>'; }
                        }
                    ]
                } );

        //});
        // alert(id_branch);
    }

    function kritis_p_2(is_pusat) {
        // alert(is_pusat)
       // $('#detail_kritis_2_p').show(function(){
            $("#detail_kritis_2_p").modal({
                backdrop: 'static'
            });
            
            $('#show_detail_kritis_2_p').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/d_gauge_kritis_2_p/" + is_pusat,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");

                                var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                                var set_value2 = value.replace(".", ",");

                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value3 = value.replace(".", ",");
                                // return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                                return '<div style="color:#090; font-weight:500;font-size:11px" >\
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai RKAP :'+ (row.RKAP_INVS_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Kontrak :'+ (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value2.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Realisasi :'+ (row.REAL_SUBPRO_VAL == null ? '0' : set_value3.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span> \
                                </div>'
                            } 
                        },
                        // { "data": "RKAP_SUBPRO_CONTRACT_VALUE", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                        //     } 
                        // },
                        // { "data": "REAL_SUBPRO_VAL", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                        //     } 
                        // },
                        { "data": "DEVIASI", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.DEVIASI).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.DEVIASI == null ? '0' : set_value.replace()+'%')
                            } 
                        },
                        { "data": "RKAP_SUBPRO_ID",
                            "render": function(data, type, row) {
                            id_subpro = row.RKAP_SUBPRO_ID;
                            return '<button class="btn btn-success btn-xs" onclick="window.open(\'<?php echo base_url() ?>subprogramrkapinvestasi/detail/'+id_subpro+'\')">' + '<i class="icon md-arrow-right"></i>' + '</button>'; }
                        }
                    ]
                } );

        //});
        // alert(id_branch);
    }

   function kritis_p_3(is_pusat) {
        // alert(is_pusat)
        //$('#detail_kritis_3_p').show(function(){
            $("#detail_kritis_3_p").modal({
                backdrop: 'static'
            });
            
            $('#show_detail_kritis_3_p').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/d_gauge_kritis_3_p/" + is_pusat,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");

                                var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                                var set_value2 = value.replace(".", ",");

                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value3 = value.replace(".", ",");
                                // return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                                return '<div style="color:#090; font-weight:500;font-size:11px" >\
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai RKAP :'+ (row.RKAP_INVS_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Kontrak :'+ (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value2.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Realisasi :'+ (row.REAL_SUBPRO_VAL == null ? '0' : set_value3.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span> \
                                </div>'
                            } 
                        },
                        // { "data": "RKAP_SUBPRO_CONTRACT_VALUE", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                        //     } 
                        // },
                        // { "data": "REAL_SUBPRO_VAL", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                        //     } 
                        // },
                        { "data": "DEVIASI", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.DEVIASI).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.DEVIASI == null ? '0' : set_value.replace()+'%')
                            } 
                        },
                        { "data": "RKAP_SUBPRO_ID",
                            "render": function(data, type, row) {
                            id_subpro = row.RKAP_SUBPRO_ID;
                            return '<button class="btn btn-success btn-xs" onclick="window.open(\'<?php echo base_url() ?>subprogramrkapinvestasi/detail/'+id_subpro+'\')">' + '<i class="icon md-arrow-right"></i>' + '</button>'; }
                        }
                    ]
                } );

        //});
        // alert(id_branch);
    }

    function kritis(id_branch) {
        // alert(is_pusat)
       // $('#detail_kritis_1').show(function(){
            $("#detail_kritis_1").modal({
                backdrop: 'static'
            });
            $('#show_detail_kritis_1').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/d_gauge_kritis_1/" + id_branch,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");

                                var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                                var set_value2 = value.replace(".", ",");

                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value3 = value.replace(".", ",");
                                // return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                                return '<div style="color:#090; font-weight:500;font-size:11px" >\
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai RKAP :'+ (row.RKAP_INVS_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Kontrak :'+ (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value2.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Realisasi :'+ (row.REAL_SUBPRO_VAL == null ? '0' : set_value3.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span> \
                                </div>'
                            } 
                        },
                        // { "data": "RKAP_SUBPRO_CONTRACT_VALUE", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                        //     } 
                        // },
                        // { "data": "REAL_SUBPRO_VAL", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                        //     } 
                        // },
                        { "data": "DEVIASI", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.DEVIASI).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.DEVIASI == null ? '0' : set_value.replace()+'%')
                            } 
                        },
                        { "data": "RKAP_SUBPRO_ID",
                            "render": function(data, type, row) {
                            id_subpro = row.RKAP_SUBPRO_ID;
                            return '<button class="btn btn-success btn-xs" onclick="window.open(\'<?php echo base_url() ?>subprogramrkapinvestasi/detail/'+id_subpro+'\')">' + '<i class="icon md-arrow-right"></i>' + '</button>'; }
                        }
                    ]
                } );

        //});
        // alert(id_branch);
    }

    function kritis_2(id_branch) {
        // alert(is_pusat)
       // $('#detail_kritis_2').show(function(){
            $("#detail_kritis_2").modal({
                backdrop: 'static'
            });
            $('#show_detail_kritis_2').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/d_gauge_kritis_2/" + id_branch,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");

                                var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                                var set_value2 = value.replace(".", ",");

                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value3 = value.replace(".", ",");
                                // return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                                return '<div style="color:#090; font-weight:500;font-size:11px" >\
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai RKAP :'+ (row.RKAP_INVS_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Kontrak :'+ (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value2.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Realisasi :'+ (row.REAL_SUBPRO_VAL == null ? '0' : set_value3.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span> \
                                </div>'
                            } 
                        },
                        // { "data": "RKAP_SUBPRO_CONTRACT_VALUE", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                        //     } 
                        // },
                        // { "data": "REAL_SUBPRO_VAL", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                        //     } 
                        // },
                        { "data": "DEVIASI", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.DEVIASI).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.DEVIASI == null ? '0' : set_value.replace()+'%')
                            } 
                        },
                        { "data": "RKAP_SUBPRO_ID",
                            "render": function(data, type, row) {
                            id_subpro = row.RKAP_SUBPRO_ID;
                            return '<button class="btn btn-success btn-xs" onclick="window.open(\'<?php echo base_url() ?>subprogramrkapinvestasi/detail/'+id_subpro+'\')">' + '<i class="icon md-arrow-right"></i>' + '</button>'; }
                        }
                    ]
                } );

        //});
        // alert(id_branch);
    }

    function kritis_3(id_branch) {
        // alert(is_pusat)
        //$('#detail_kritis_3').show(function(){
            $("#detail_kritis_3").modal({
                backdrop: 'static'
            });
            $('#show_detail_kritis_3').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/d_gauge_kritis_3/" + id_branch,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");

                                var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                                var set_value2 = value.replace(".", ",");

                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value3 = value.replace(".", ",");
                                // return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                                return '<div style="color:#090; font-weight:500;font-size:11px" >\
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai RKAP :'+ (row.RKAP_INVS_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Kontrak :'+ (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value2.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Realisasi :'+ (row.REAL_SUBPRO_VAL == null ? '0' : set_value3.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span> \
                                </div>'
                            } 
                        },
                        // { "data": "RKAP_SUBPRO_CONTRACT_VALUE", 
                        //     "render": function(data, type, row){
                        //         return (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : row.RKAP_SUBPRO_CONTRACT_VALUE.replace(/\B(?=(\d{3})+(?!\d))/g, '.'))
                        //     } 
                        // },
                        // { "data": "REAL_SUBPRO_VAL", 
                        //     "render": function(data, type, row){
                        //         return (row.REAL_SUBPRO_VAL == null ? '0' : row.REAL_SUBPRO_VAL.replace(/\B(?=(\d{3})+(?!\d))/g, '.'))
                        //     } 
                        // },
                        { "data": "DEVIASI", 
                            "render": function(data, type, row){
                                return (row.DEVIASI == null ? '0' : row.DEVIASI.replace()+'%')
                            } 
                        },
                        { "data": "RKAP_SUBPRO_ID",
                            "render": function(data, type, row) {
                            id_subpro = row.RKAP_SUBPRO_ID;
                            return '<button class="btn btn-success btn-xs" onclick="window.open(\'<?php echo base_url() ?>subprogramrkapinvestasi/detail/'+id_subpro+'\')">' + '<i class="icon md-arrow-right"></i>' + '</button>'; }
                        }
                    ]
                } );

        //});
        // alert(id_branch);
    }

    $('#closeKritis1').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kritis_1').hide();
    });

    $('#closeKritis2').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kritis_2').hide();
    });

    $('#closeKritis3').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kritis_3').hide();
    });

    function kritis_awal(id_branch) {
        // alert(is_pusat)
       // $('#detail_kritis_1_awal').show(function(){
            $("#detail_kritis_1_awal").modal({
                backdrop: 'static'
            });
            
            $('#show_detail_kritis_1_awal').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/d_gauge_kritis_1_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>",
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");

                                var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                                var set_value2 = value.replace(".", ",");

                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value3 = value.replace(".", ",");
                                // return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                                return '<div style="color:#090; font-weight:500;font-size:11px" >\
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai RKAP :'+ (row.RKAP_INVS_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Kontrak :'+ (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value2.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Realisasi :'+ (row.REAL_SUBPRO_VAL == null ? '0' : set_value3.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span> \
                                </div>'
                            } 
                        },
                        // { "data": "RKAP_SUBPRO_CONTRACT_VALUE", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                        //     } 
                        // },
                        // { "data": "REAL_SUBPRO_VAL", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                        //     } 
                        // },
                        { "data": "DEVIASI", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.DEVIASI).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.DEVIASI == null ? '0' : set_value.replace()+'%')
                            } 
                        },
                        { "data": "RKAP_SUBPRO_ID",
                            "render": function(data, type, row) {
                            id_subpro = row.RKAP_SUBPRO_ID;
                            return '<button class="btn btn-success btn-xs" onclick="window.open(\'<?php echo base_url() ?>subprogramrkapinvestasi/detail/'+id_subpro+'\')">' + '<i class="icon md-arrow-right"></i>' + '</button>'; }
                        }
                    ]
                } );

        //});
        // alert(id_branch);
    }

    function kritis_2_awal(id_branch) {
        // alert(is_pusat)
       // $('#detail_kritis_2_awal').show(function(){
            $("#detail_kritis_2_awal").modal({
                backdrop: 'static'
            });
            
            $('#show_detail_kritis_2_awal').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/d_gauge_kritis_2_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>",
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");

                                var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                                var set_value2 = value.replace(".", ",");

                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value3 = value.replace(".", ",");
                                // return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                                return '<div style="color:#090; font-weight:500;font-size:11px" >\
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai RKAP :'+ (row.RKAP_INVS_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Kontrak :'+ (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value2.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Realisasi :'+ (row.REAL_SUBPRO_VAL == null ? '0' : set_value3.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span> \
                                </div>'
                            } 
                        },
                        // { "data": "RKAP_SUBPRO_CONTRACT_VALUE", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                        //     } 
                        // },
                        // { "data": "REAL_SUBPRO_VAL", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.REAL_SUBPRO_VAL == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                        //     } 
                        // },
                        { "data": "DEVIASI", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.DEVIASI).toFixed(2);
                                var set_value = value.replace(".", ",");
                                return (row.DEVIASI == null ? '0' : set_value.replace()+'%')
                            } 
                        },
                        { "data": "RKAP_SUBPRO_ID",
                            "render": function(data, type, row) {
                            id_subpro = row.RKAP_SUBPRO_ID;
                            return '<button class="btn btn-success btn-xs" onclick="window.open(\'<?php echo base_url() ?>subprogramrkapinvestasi/detail/'+id_subpro+'\')">' + '<i class="icon md-arrow-right"></i>' + '</button>'; }
                        }
                    ]
                } );

        //});
        // alert(id_branch);
    }

    function kritis_3_awal(id_branch) {
        // alert(is_pusat)
        //$('#detail_kritis_3_awal').show(function(){
            $("#detail_kritis_3_awal").modal({
                backdrop: 'static'
            });
            
            $('#show_detail_kritis_3_awal').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/d_gauge_kritis_3_awal/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>",
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");

                                var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                                var set_value2 = value.replace(".", ",");

                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value3 = value.replace(".", ",");
                                // return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                                return '<div style="color:#090; font-weight:500;font-size:11px" >\
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai RKAP :'+ (row.RKAP_INVS_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Kontrak :'+ (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value2.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Realisasi :'+ (row.REAL_SUBPRO_VAL == null ? '0' : set_value3.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span> \
                                </div>'
                            } 
                        },
                        // { "data": "RKAP_SUBPRO_CONTRACT_VALUE", 
                        //     "render": function(data, type, row){
                        //         return (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : row.RKAP_SUBPRO_CONTRACT_VALUE.replace(/\B(?=(\d{3})+(?!\d))/g, '.'))
                        //     } 
                        // },
                        // { "data": "REAL_SUBPRO_VAL", 
                        //     "render": function(data, type, row){
                        //         return (row.REAL_SUBPRO_VAL == null ? '0' : row.REAL_SUBPRO_VAL.replace(/\B(?=(\d{3})+(?!\d))/g, '.'))
                        //     } 
                        // },
                        { "data": "DEVIASI", 
                            "render": function(data, type, row){
                                return (row.DEVIASI == null ? '0' : row.DEVIASI.replace()+'%')
                            } 
                        },
                        { "data": "RKAP_SUBPRO_ID",
                            "render": function(data, type, row) {
                            id_subpro = row.RKAP_SUBPRO_ID;
                            return '<button class="btn btn-success btn-xs" onclick="window.open(\'<?php echo base_url() ?>subprogramrkapinvestasi/detail/'+id_subpro+'\')">' + '<i class="icon md-arrow-right"></i>' + '</button>'; }
                        }
                    ]
                } );
        //});
        // alert(id_branch);
    }

    $('#closeKritis1_awal').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kritis_1_awal').hide();
    });

    $('#closeKritis2_awal').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kritis_2_awal').hide();
    });

    $('#closeKritis3_awal').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kritis_3_awal').hide();
    });
    
    //DETAIL GAUGE KRITIS
    function kritis_p_all() {
        // alert(is_pusat)
        // $('#detail_kritis_1_all').show(function(){
        $("#detail_kritis_1_all").modal({
            backdrop: 'static'
        });

            $('#show_detail_kritis_1_all').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/d_gauge_kritis_1_all/" ,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");

                                var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                                var set_value2 = value.replace(".", ",");

                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value3 = value.replace(".", ",");
                                // return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                                return '<div style="color:#090; font-weight:500;font-size:11px" >\
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai RKAP :'+ (row.RKAP_INVS_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Kontrak :'+ (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value2.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Realisasi :'+ (row.REAL_SUBPRO_VAL == null ? '0' : set_value3.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span> \
                                </div>'
                            } 
                        },
                        // { "data": "RKAP_SUBPRO_CONTRACT_VALUE", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.'))
                        //     } 
                        // },
                        // { "data": "REAL_SUBPRO_VAL", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.REAL_SUBPRO_VAL == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.'))
                        //     } 
                        // },
                        { "data": "DEVIASI", 
                            "render": function(data, type, row){
                                return (row.DEVIASI == null ? '0' : row.DEVIASI.replace()+'%')
                            } 
                        },
                        { "data": "BRANCH_ID",
                            "render": function(data, type, row) {
                            id_subpro = row.RKAP_SUBPRO_ID;
                            return '<button class="btn btn-success btn-xs" onclick="window.open(\'<?php echo base_url() ?>subprogramrkapinvestasi/detail/'+id_subpro+'\')">' + '<i class="icon md-arrow-right"></i>' + '</button>'; }
                        }
                    ]
                } );

        // });
        // alert(id_branch);
    }

    function kritis_p_2_all() {
        // alert(is_pusat)
        // $('#detail_kritis_2_all').show(function(){
        $("#detail_kritis_2_all").modal({
            backdrop: 'static'
        });

            $('#show_detail_kritis_2_all').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/d_gauge_kritis_2_all/" ,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");

                                var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                                var set_value2 = value.replace(".", ",");

                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value3 = value.replace(".", ",");
                                // return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                                return '<div style="color:#090; font-weight:500;font-size:11px" >\
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai RKAP :'+ (row.RKAP_INVS_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Kontrak :'+ (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value2.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Realisasi :'+ (row.REAL_SUBPRO_VAL == null ? '0' : set_value3.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span> \
                                </div>'
                            } 
                        },
                        // { "data": "RKAP_SUBPRO_CONTRACT_VALUE", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.'))
                        //     } 
                        // },
                        // { "data": "REAL_SUBPRO_VAL", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.REAL_SUBPRO_VAL == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.'))
                        //     } 
                        // },
                        { "data": "DEVIASI", 
                            "render": function(data, type, row){
                                return (row.DEVIASI == null ? '0' : row.DEVIASI.replace()+'%')
                            } 
                        },
                        { "data": "BRANCH_ID",
                            "render": function(data, type, row) {
                            id_subpro = row.RKAP_SUBPRO_ID;
                            return '<button class="btn btn-success btn-xs" onclick="window.open(\'<?php echo base_url() ?>subprogramrkapinvestasi/detail/'+id_subpro+'\')">' + '<i class="icon md-arrow-right"></i>' + '</button>'; }
                        }
                    ]
                } );

        // });
        // alert(id_branch);
    }

    function kritis_p_3_all() {
        // alert(is_pusat)
        // $('#detail_kritis_3_all').show(function(){
        $("#detail_kritis_3_all").modal({
            backdrop: 'static'
        });

            $('#show_detail_kritis_3_all').DataTable( {
                    "ajax": "<?php echo base_url() ?>home/d_gauge_kritis_3_all/" ,
                    "destroy": "true",
                    "columns": [
                        { "data": "BRANCH_NAME" },
                        { "data": "RKAP_INVS_TITLE" },
                        { "data": "RKAP_SUBPRO_TITTLE" },
                        { "data": "RKAP_INVS_VALUE", 
                            "render": function(data, type, row){
                                var value = parseFloat(row.RKAP_INVS_VALUE).toFixed(2);
                                var set_value = value.replace(".", ",");

                                var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                                var set_value2 = value.replace(".", ",");

                                var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                                var set_value3 = value.replace(".", ",");
                                // return (row.RKAP_INVS_VALUE == null ? '0' : "Rp. "+set_value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1."))
                                return '<div style="color:#090; font-weight:500;font-size:11px" >\
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai RKAP :'+ (row.RKAP_INVS_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Kontrak :'+ (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value2.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span><br/><hr/> \
                                    <span class="labelGrid">\
                                        <i class="icon md-receipt"></i>\
                                        Nilai Realisasi :'+ (row.REAL_SUBPRO_VAL == null ? '0' : set_value3.replace(/\B(?=(\d{3})+(?!\d))/g, '.')) +'\
                                    </span> \
                                </div>'
                            } 
                        },
                        // { "data": "RKAP_SUBPRO_CONTRACT_VALUE", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.RKAP_SUBPRO_CONTRACT_VALUE).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.RKAP_SUBPRO_CONTRACT_VALUE == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.'))
                        //     } 
                        // },
                        // { "data": "REAL_SUBPRO_VAL", 
                        //     "render": function(data, type, row){
                        //         var value = parseFloat(row.REAL_SUBPRO_VAL).toFixed(2);
                        //         var set_value = value.replace(".", ",");
                        //         return (row.REAL_SUBPRO_VAL == null ? '0' : set_value.replace(/\B(?=(\d{3})+(?!\d))/g, '.'))
                        //     } 
                        // },
                        { "data": "DEVIASI", 
                            "render": function(data, type, row){
                                return (row.DEVIASI == null ? '0' : row.DEVIASI.replace()+'%')
                            } 
                        },
                        { "data": "BRANCH_ID",
                            "render": function(data, type, row) {
                            id_subpro = row.RKAP_SUBPRO_ID;
                            return '<button class="btn btn-success btn-xs" onclick="window.open(\'<?php echo base_url() ?>subprogramrkapinvestasi/detail/'+id_subpro+'\')">' + '<i class="icon md-arrow-right"></i>' + '</button>'; }
                        }
                    ]
                } );

        // });
        // alert(id_branch);
    }

    $('#closeKritis3_all').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kritis_3_all').hide();
    });

    $('#close_all').click(function pass_cek(e) {
        e.preventDefault();
        $('#modal_all').hide();
    });

   $('#closeKritis1_all').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kritis_1_all').hide();
    });
   $('#closeKritis2_all').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kritis_2_all').hide();
    });
   $('#closeKritis3_all').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kritis_3_all').hide();
    });

    $('#closeKritis1_p').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kritis_1_p').hide();
    });

    $('#closeKritis2_p').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kritis_2_p').hide();
    });

    $('#closeKritis3_p').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kritis_3_p').hide();
    });

    //cabang
    $('#closeD_posisi').click(function pass_cek(e) {
            e.preventDefault();
            $('#detail_posisi').hide();
            $('#posisi').show();
        });

    $('#closeD_posisi_awal').click(function pass_cek(e) {
            e.preventDefault();
            $('#detail_posisi_awal').hide();
            $('#posisi_awal').show();
        });

    $('#closeD_posisi_p').click(function pass_cek(e) {
            e.preventDefault();
            $('#detail_posisi_p').hide();
            $('#posisi_p').show();
        });

    //pusat
    $('#closeD_status').click(function pass_cek(e) {
            e.preventDefault();
            $('#detail_status').hide();
            $('#status').show();
        });

    $('#closeD_status_awal').click(function pass_cek(e) {
            e.preventDefault();
            $('#detail_status_awal').hide();
            $('#status_awal').show();
        });
    /*close modal pusat*/

    $('#closeD_status_p').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_status_p').hide();
        $('#status_p').show();
    });

    $('#closeD_kendala_p').click(function pass_cek(e) {
        e.preventDefault();
        $('#detail_kendala_p').hide();
        $('#kendala_p').show();
    });

    $('#close_modal').click(function pass_cek(e) {
        e.preventDefault();
        $('#modal_pusat').hide();
        $('#profil_p').hide();
        $('#kontrak_p').hide();
        $('#posisi_p').hide();
        $('#status_p').hide();
        $('#Kendala_p').hide();
        $("#graph11").empty();
        $("#graph22").empty();
        $("#graph33").empty();
        $("#graph44").empty();
        $("#graph55").empty();
        $("#graph66").empty();

    });

    $('#closeProfil_p').click(function pass_cek(e) {
        e.preventDefault();
        $('#profil_p').hide();
    });

    $('#closeKontrak_p').click(function pass_cek(e) {
        e.preventDefault();
        $('#kontrak_p').hide();
        // coba(id_branch);
    });

    $('#closePosisi_p').click(function pass_cek(e) {
        e.preventDefault();
        $('#posisi_p').hide();
    });

    $('#closeStatus_p').click(function pass_cek(e) {
        e.preventDefault();
        $('#status_p').hide();
    });

    $('#closeKendala_p').click(function pass_cek(e) {
        e.preventDefault();
        $('#kendala_p').hide();
    });
</script>

<script type="text/javascript">
    var act = $('#act').val();
    // alert(act);

    if (act == 'detail') {
        $("#addrkapinvestasi input").attr('disabled', 'disabled');
        $("#addrkapinvestasi select").attr('disabled', 'disabled');
        $("#addrkapinvestasi  #button-edit").hide();
        $("#addrkapinvestasi  #button-add").hide();
        $("#addsubprogramrkapinvestasi input").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi select").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-add").hide();
        $("#addsubprogramrkapinvestasi  #button-edit").hide();
        $("#addsubprogramrkapinvestasi  #button-back").hide();
        $("#entryaddendum input").attr('disabled', 'disabled');
        $("#entryaddendum select").attr('disabled', 'disabled');
        $("#entryaddendum  #button-add").hide();
        $("#entryaddendum  #button-edit").hide();
        $("#entryaddendum  #button-back").hide();
        $("#addrealisasi  #button-add").hide();
        $("#addrealisasi  #button-edit").hide();
        $("#addrealisasi  #button-back").hide();
        $("#addrealisasi input").attr('disabled', 'disabled');
        $("#addrealisasi select").attr('disabled', 'disabled');
        $("#addrealisasi textarea").attr('disabled', 'disabled');
        $("#entryrisiko  #button-edit").hide();
        $("#entryrisiko  #button-add").hide();
        // $("#addrealisasi  #button-monitoring").attr('disabled', 'disabled');
    } else if (act == 'add') {
        $("#addrkapinvestasi  #button-edit").hide();
        $("#addrkapinvestasi  #button-list").attr('disabled', 'disabled');
        $("#addrkapinvestasi  #button-tambah-subadd").attr('disabled', 'disabled');
        $("#addrkapinvestasi  #button-gantt-chart").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-kurva").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-entry-risiko").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-view-addendum").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-entry-addendum").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-view-realisasi").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-entry-realisasi").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-edit").hide();
        $("#entryaddendum  #button-edit").hide();
        $("#addrealisasi  #button-edit").hide();
        $("#addrealisasi  #button-monitoring").attr('disabled', 'disabled');
        $("#entryrisiko  #button-edit").hide();

    } else if (act == 'edit') {
        $("#addrkapinvestasi  #button-add").hide();
        $("#addrkapinvestasi  #button-list").attr('disabled', 'disabled');
        $("#addrkapinvestasi  #button-tambah-subedit").attr('disabled', 'disabled');
        $("#addrkapinvestasi  #button-gantt-chart").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-back").hide();
        $("#addsubprogramrkapinvestasi  #button-kurva").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-entry-risiko").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-view-addendum").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-entry-addendum").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-view-realisasi").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-entry-realisasi").attr('disabled', 'disabled');
        $("#addsubprogramrkapinvestasi  #button-add").hide();
        $("#entryaddendum  #button-add").hide();
        $("#entryaddendum  #button-back").hide();
        $("#addrealisasi  #button-add").hide();
        $("#addrealisasi  #button-back").hide();
        $("#addrealisasi  #button-monitoring").attr('disabled', 'disabled');
        $("#entryrisiko  #button-add").hide();

    }
    
    
    function modalEWSkontrak(){
        $("#modalEWS-kontrak-kritis").modal({
            backdrop: 'static'
        }); 
    }
    
    function modalEWSsubprogram(){
        $("#modalEWS-start-sub-program").modal({
            backdrop: 'static'
        }); 
    }
    
    function modalEWSrealisasi(){
        $("#modalEWS-realisasi-pelaporan").modal({
            backdrop: 'static'
        }); 
    }
    
    function modalEWSkontrakBA(){
        $("#modalEWS-kontrak-B-A").modal({
            backdrop: 'static'
        }); 
    }

    function reporting_awal(id_branch) {
        $("#reporting_awal").modal({
            backdrop: 'static'
        });
    }

    function reporting(id_branch) {
        $("#reporting").modal({
            backdrop: 'static'
        });

        $.ajax({
            url:"<?php echo base_url() ?>home/profil/" + id_branch,
            success(res){
                var data = JSON.parse(res);
                //console.log(data);
                $('#nama_cabang2').text(data.data['DISPLAY_NAME']);
                
            }
        })
    }

    function report(id_branch) {
        var show_month      = $('#show_month2').val();
        var show_years      = $('#show_years2').val();
        var show_tanggal    = $('#show_tanggal').val();
        var show_month21      = $('#show_month21').val();
        var show_years21      = $('#show_years21').val();
        var show_tanggal21    = $('#show_tanggal21').val();

        var nshow_month = parseInt(show_month);
        var nshow_years = parseInt(show_years);
 
        var nshow_month21 = parseInt(show_month21);
        var nshow_years21 = parseInt(show_years21);

        if ((nshow_month <= nshow_month21) && (nshow_years == nshow_years21)) {
            window.open("<?php echo base_url() ?>report_detail/detailmmr/"+ id_branch+"/report/" + nshow_years+ "/" + show_tanggal21 +"/"+ nshow_month +"/" + nshow_month21, "_blank");
            $('#report_date2').val('');
            $('#report_date21').val('');
            $('#btn_report_date2').attr('disabled', true);
        }else{
            alert("Error: Tanggal Awal Tidak Boleh Lebih Dari tanggal Akhir & Tahun Tidak Boleh Berbeda !!");
        }

    }

    function report_awal() {
        var show_month      = $('#show_month').val();
        var show_years      = $('#show_years').val();
        var show_tanggal    = $('#report_date').val();
        var show_month12      = $('#show_month12').val();
        var show_years12      = $('#show_years12').val();
        var show_tanggal12    = $('#report_date12').val();
        
        var nshow_month = parseInt(show_month);
        var nshow_years = parseInt(show_years);
 
        var nshow_month12 = parseInt(show_month12);
        var nshow_years12 = parseInt(show_years12);

        if ((nshow_month <= nshow_month12) && (nshow_years == nshow_years12)) {
            window.open("<?php echo base_url() ?>report_detail/detailmmr/<?php echo $this->session->userdata('SESS_USER_BRANCH') ?>/report/" + nshow_years+ "/" + show_tanggal12 +"/"+ nshow_month +"/" + nshow_month12, "_blank");
            $('#report_date').val('');
            $('#report_date12').val('');
            $('#btn_report_date').attr('disabled', true);
        }else{
            alert("Error: Tanggal Awal Tidak Boleh Lebih Dari tanggal Akhir & Tahun Tidak Boleh Berbeda !!");
        }
    }

    function get_report_date(){
        var tanggal     = $('#report_date').val();
        var tanggal12     = $('#report_date12').val();

        var _tglMulai   = new Date(tanggal); 
        var bulan       = _tglMulai.getMonth() + 1;
        var tahun       = _tglMulai.getFullYear();


        $('#show_month').val(bulan);
        $('#show_years').val(tahun);

        if (tanggal == '' || tanggal12 == '') {

            $('#btn_report_date').attr('disabled', true);
        } else {
            
            $('#btn_report_date').attr('disabled', false);
        }
        // alert(date)
    }

    function get_report_date12(){
        var tanggal12     = $('#report_date12').val();
        var tanggal     = $('#report_date').val();

        var _tglMulai12   = new Date(tanggal12); 
        var bulan12       = _tglMulai12.getMonth() + 1;
        var tahun12       = _tglMulai12.getFullYear();


        $('#show_month12').val(bulan12);
        $('#show_years12').val(tahun12);

        if (tanggal12 == '' || tanggal == '') {

            $('#btn_report_date').attr('disabled', true);
        } else {
            
            $('#btn_report_date').attr('disabled', false);
        }
        // alert(date)
    }

    function get_report_date2(){
        var tanggal     = $('#report_date2').val();
        var tanggal21     = $('#report_date21').val();

        var _tglMulai   = new Date(tanggal); 
        var bulan       = _tglMulai.getMonth() + 1;
        var tahun       = _tglMulai.getFullYear();


        $('#show_month2').val(bulan);
        $('#show_years2').val(tahun);
        $('#show_tanggal').val(tanggal);

        if (tanggal == '' || tanggal21 == '') {

            $('#btn_report_date2').attr('disabled', true);
        } else {
            
            $('#btn_report_date2').attr('disabled', false);
        }
        // alert(date)
    }

    function get_report_date21(){
        var tanggal     = $('#report_date21').val();
        var tanggal21     = $('#report_date21').val();

        var _tglMulai   = new Date(tanggal); 
        var bulan       = _tglMulai.getMonth() + 1;
        var tahun       = _tglMulai.getFullYear();


        $('#show_month21').val(bulan);
        $('#show_years21').val(tahun);
        $('#show_tanggal21').val(tanggal);

        if (tanggal == '' || tanggal21 == '') {

            $('#btn_report_date2').attr('disabled', true);
        } else {
            
            $('#btn_report_date2').attr('disabled', false);
        }
        // alert(date)
    }

    $("#report_date").datepicker( {
        format: "yyyy-mm",
        viewMode: "months", 
        minViewMode: "months"
    });
    
    $("#realisasifisik").datepicker( {
        format: "mm-yyyy",
        minViewMode: "months"
    });

    $("#kpirealisasi").datepicker( {
        format: "mm-yyyy",
        minViewMode: "months"
    });

    $("#report_date12").datepicker( {
        format: "yyyy-mm",
        viewMode: "months", 
        minViewMode: "months"
    });

    $("#report_date2").datepicker( {
        format: "yyyy-mm",
        viewMode: "months", 
        minViewMode: "months"
    });

    $("#report_date21").datepicker( {
        format: "yyyy-mm",
        viewMode: "months", 
        minViewMode: "months"
    });

    $("#tgl_deadline").datepicker( {
        format: "dd-mm-yyyy",
        viewMode: "day", 
        minViewMode: "day"
    });


</script>
<script type="text/javascript">
    <?php
    if ($this->session->userdata('SESS_USER_POSITION') == 2) {
        ?>
        $(window).on('load',function(){
            $('#BannerAwal').modal({
                backdrop: 'static',
                keyboard: false
            });
        });
        <?php
    }
    ?>
</script>
</body>
</html>