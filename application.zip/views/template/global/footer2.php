<!-- BEGIN FOOTER -->


<script src="<?php echo base_url(); ?>assets/template/global/plugins/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/template/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" type="text/javascript">></script>
<script>
$(document).ready(function () {
    tampil_data_rkap();
    tampil_data_kontrak();
    tampil_data_realisasi();
    tampil_data_addendum();
    $('#mydata1').dataTable();
    $('#mydata2').dataTable();
    $('#mydata3').dataTable();
    $('#mydata4').dataTable();

    $("#btnrkap").click(function () {
        var vcab = $("#cabangrkap").val();
        var urls = "projectcostingcems/prosesrkap/" + vcab;
        $('#loadingrkap').show();
        $.ajax({
            type: "get",
            url: urls,
            success: function (data) {
                //console.log(data);
                $('#loadingrkap').hide();
                $('#alertrkap').show();
                setTimeout(function () {
                    $('#alertrkap').hide();
                }, 5000);
                tampil_data_rkap();
            }
        });
    });

    $("#btnkontrak").click(function () {
        var vcab = $("#cabangkontrak").val();
        var urls = "projectcostingcems/proseskontrak/" + vcab;
        $('#loadingkontrak').show();
        $.ajax({
            type: "get",
            url: urls,
            success: function (data) {
                //console.log(data);
                $('#loadingkontrak').hide();
                $('#alertkontrak').show();
                setTimeout(function () {
                    $('#alertkontrak').hide();
                }, 5000);
                tampil_data_kontrak();
            }
        });

    });

    $("#btnrealisasi").click(function () {
        var vcab = $("#cabangrealisasi").val();
        var urls = "projectcostingcems/prosesrealisasi/" + vcab;
        $('#loadingrealisasi').show();
        $.ajax({
            type: "get",
            url: urls,
            success: function (data) {
                //console.log(data);
                $('#loadingrealisasi').hide();
                $('#alertrealisasi').show();
                setTimeout(function () {
                    $('#alertrealisasi').hide();
                }, 5000);
                tampil_data_realisasi();
            }
        });

    });

    $("#regeneratereal").click(function () {
        var urls = "projectcostingcems/prosesmasukrealisasi";
        
        $.ajax({
            type: "get",
            url: urls,
            success: function (data) {
                //console.log(data);
                $('#loadingrealisasi').show();
                $('#alertrealisasi').show();
                setTimeout(function () {
                    $('#alertrealisasi').hide();
                    $('#loadingrealisasi').hide();
                }, 5000);
                tampil_data_realisasi();
            }
        });
        
    });

    $("#btnaddendum").click(function () {
        var vcab = $("#cabangaddendum").val();
        var urls = "projectcostingcems/prosesaddendum/" + vcab;
        $('#loadingaddendum').show();
        $.ajax({
            type: "get",
            url: urls,
            success: function (data) {
                //console.log(data);
                $('#loadingaddendum').hide();
                $('#alertaddendum').show();
                setTimeout(function () {
                    $('#alertaddendum').hide();
                }, 5000);
                tampil_data_addendum();
            }
        });

    });


    //-----------------------------------------------------------------------------

    $("#btnrkap_2").click(function () {
        var vcab = $("#cabangrkap").val();
        var urls = "projectcostingcems/prosesrkap/" + vcab;
        $('#loadingrkap').show();
        $.ajax({
            type: "get",
            url: urls,
            success: function (data) {
                //console.log(data);
                $('#loadingrkap').hide();
                $('#alertrkap').show();
                setTimeout(function () {
                    $('#alertrkap').hide();
                }, 5000);
                tampil_data_rkap();

            }
        });

    });

    $("#btnkontrak_2").click(function () {
        var vcab = $("#cabangkontrak").val();
        var urls = "projectcostingcems/proseskontrak_month/" + vcab;
        $('#loadingkontrak').show();
        $.ajax({
            type: "get",
            url: urls,
            success: function (data) {
                //console.log(data);
                $('#loadingkontrak').hide();
                $('#alertkontrak').show();
                setTimeout(function () {
                    $('#alertkontrak').hide();
                }, 5000);
                tampil_data_kontrak();
            }
        });

    });

    $("#btnrealisasi_2").click(function () {
        var vcab = $("#cabangrealisasi").val();
        var urls = "projectcostingcems/prosesrealisasi_month/" + vcab;
        $('#loadingrealisasi').show();
        $.ajax({
            type: "get",
            url: urls,
            success: function (data) {
                //console.log(data);
                $('#loadingrealisasi').hide();
                $('#alertrealisasi').show();
                setTimeout(function () {
                    $('#alertrealisasi').hide();
                }, 5000);
                tampil_data_realisasi();
            }
        });

    });


    
    function tampil_data_rkap() {
        $.ajax({
            type: 'ajax',
            url: 'projectcostingcems/datatable/RKAP',
            success: function (datas) {
                data = $.parseJSON(datas);
                // console.log(data);
                // console.log(data.length);
                var html = '';
                var i;
                for (i = 0; i < data.length; i++) {
                    html += '<tr>' +
                        '<td>' + cab(data[i].CABANG) + '</td>' +
                        '<td>' + data[i].DATA_MASUK + '</td>' +
                        '<td>' + data[i].TGL + '</td>' +
                        '</tr>';
                }
                $('#show_data1').html(html);
            }

        });
    }
    function tampil_data_kontrak() {
        $.ajax({
            type: 'ajax',
            url: 'projectcostingcems/datatable/KONTRAK',
            success: function (datas) {
                data = $.parseJSON(datas);
                // console.log(data);
                // console.log(data.length);
                var html = '';
                var i;
                for (i = 0; i < data.length; i++) {
                    html += '<tr>' +
                        '<td>' + cab(data[i].CABANG) + '</td>' +
                        '<td>' + data[i].DATA_MASUK + '</td>' +
                        '<td>' + data[i].TGL + '</td>' +
                        '</tr>';
                }
                $('#show_data2').html(html);
            }

        });
    }
    function tampil_data_realisasi() {
        $.ajax({
            type: 'ajax',
            url: 'projectcostingcems/datatable/REALISASI',
            success: function (datas) {
                data = $.parseJSON(datas);
                // console.log(data);
                // console.log(data.length);
                var html = '';
                var i;
                for (i = 0; i < data.length; i++) {
                    html += '<tr>' +
                        '<td>' + cab(data[i].CABANG) + '</td>' +
                        '<td>' + data[i].DATA_MASUK + '</td>' +
                        '<td>' + data[i].TGL + '</td>' +
                        '</tr>';
                }
                $('#show_data3').html(html);
            }

        });
    }
    function tampil_data_addendum() {
        $.ajax({
            type: 'ajax',
            url: 'projectcostingcems/datatable/ADDENDUM',
            success: function (datas) {
                data = $.parseJSON(datas);
                // console.log(data);
                // console.log(data.length);
                var html = '';
                var i;
                for (i = 0; i < data.length; i++) {
                    html += '<tr>' +
                        '<td>' + cab(data[i].CABANG) + '</td>' +
                        '<td>' + data[i].DATA_MASUK + '</td>' +
                        '<td>' + data[i].TGL + '</td>' +
                        '</tr>';
                }
                $('#show_data4').html(html);
            }

        });
    }
    function cab(dt) {
        if (dt == 82) {
            return 'Kantor Pusat';
        }else if(dt == 83){
            return 'Tanjung Priok';
        }else {
            return dt;
        }
    }

});
</script>
</body>
</html>