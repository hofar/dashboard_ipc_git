<html>
    <head>
        <meta charset="utf-8"/>
        <title>Dashboard Realisasi Investasi  </title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport"/>
        <meta content="" name="description"/>
        <meta content="" name="author"/>
        <style>
            .headPanel{
                padding-top:10px;
                padding-right:15px !important;
                background-color:#324a5e;
                color:#FFF !important;
            }

            a{
                text-decoration:none !important;
            }

            .headTable{
                font-size:14px !important;
                color:#666 !important;
                background-color:#F3F3F3 !important;
                font-weight:500 !important
            }

            .panels{
                background-color:#FFF; padding:15px;
            }

            .headTab{
                background-color:#EDEDED;
                color:#585858;
                padding:12px 20px;
                font-size:18px;
            }

            #gaugeKritis7 {
                width   : 50%;
                height  : 50%;
                background-color: #fff;
            }

            #gaugeKritis8 {
                width   : 50%;
                height  : 50%;
                background-color: #fff;
            }

            #gaugeKritis9 {
                width   : 50%;
                height  : 50%;
                background-color: #fff;
            }

            .label-size {
                font-size: 12px;
                margin-left: 85px;
            }

            .ipc-image {
                width: 115px;
                /*padding-bottom: : 20px;*/
            }

            .headAccount{
                margin-bottom:18px;font-size:16px; background-color:#FFF; color:#666;padding:15px 20px;
                box-shadow: rgba(204,204,204,0.20) 0px 3px 5px 0px
            }


            #modal_all {
                width: 800px;
                position: absolute;
                right: 0.5cm;
                top: 23px;
                opacity: 0.97;
                margin-right: 7px;
                margin-top: 60px;
                margin-left:0px !important;
                display: none;
                box-shadow:rgba(204,204,204,0.90) 1px 1px 12px 0px;
            }

            #placeholder_awal {
                width: 800px;
                position: absolute;
                right: 0.5cm;
                top: 23px;
                margin-right: 7px !important;
                opacity:0.98;
                margin-top: 60px;
                box-shadow:rgba(204,204,204,0.90) 3px 3px 12px 0px;
            }


            #chartdiv {
                background-color: #FFF; 
                color: #fff;
                width: 100%;
                height: 100%;
                /*padding-left: 10px;
padding-right: 10px;*/
                padding: 0px 30px;
            }

            .divMaps{
                background-color:#FFF;padding:10px;
                box-shadow:rgba(204,204,204,0.50) 3px 3px 10px 0px;
            }

            #gaugeKritis {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #gaugeKritis2 {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #gaugeKritis3 {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #gaugeKritisawal {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #gaugeKritis2awal {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #gaugeKritis3awal {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #gaugeDetails1awal {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #gaugeDetails2awal {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #gaugeDetails3awal {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #pieDetails4awal {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
                fill: #FF2B2B !important; 
            }

            #tabung1awal {
                width   : 100%;
                height  : 230px;
                background-color: #848886;
            }

            #tabung2awal {
                width   : 100%;
                height  : 230px;
                background-color: #848886;
                color:#fff;
            }

            #gaugeDetails1 {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #gaugeDetails2 {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #gaugeDetails3 {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #pieDetails4 {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
                fill: #84b761 !important; 
            }

            #tabung1 {
                width   : 100%;
                height  : 230px;
                background-color: #848886;
            }

            #tabung2 {
                width   : 100%;
                height  : 230px;
                background-color: #848886;
                color:#fff;
            }

            #placeholder {
                width: 800px;
                position: absolute;
                right: 0.5cm;
                top: 23px;
                margin-right: 7px !important;
                opacity:0.98;
                margin-top: 60px;
                box-shadow:rgba(204,204,204,0.90) 3px 3px 12px 0px;
            }

            #profil {
                width: 600px;
                height: 500px;
                position: absolute;
                right: 0;
                top: 83px;
                opacity: 0.9;
            }

            .amcharts-chart-div a {
                display:none !important;
            }

            .amcharts-chart-div {

            }

            /*pusat*/
            #modal_pusat {
                width: 800px;
                position: absolute;
                right: 0.5cm;
                top: 23px;
                margin-right: 7px !important;
                opacity:0.98;
                margin-top: 60px;
                box-shadow:rgba(204,204,204,0.90) 3px 3px 12px 0px;
            }

            /*#gaugeKritis4 {
                width   : 32%;
                height  : 30%;
                background-color: #fff;
            }*/

            /*#gaugeKritis5 {
                width   : 32%;
                height  : 30%;
                background-color: #fff;
            }*/

            /*#gaugeKritis6 {
                width   : 32%;
                height  : 30%;
                background-color: #fff;
            }*/

            .gaugeKritis{
                width:100%;
                height:100px;
            }

            #p_gaugeDetails1 {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #p_gaugeDetails2 {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #p_gaugeDetails3 {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #p_pieDetails4 {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #p_tabung1 {
                width   : 100%;
                height  : 230px;
                background-color: #EBEBEB;
            }

            #p_tabung2 {
                width   : 100%;
                height  : 230px;
                background-color: #EBEBEB;
                color:#fff;
            }

            /*all*/

            /*#all_gaugeKritis4 {
                width   : 32%;
                height  : 30%;
                background-color: #fff;
            }

            #all_gaugeKritis5 {
                width   : 32%;
                height  : 30%;
                background-color: #fff;
            }

            #all_gaugeKritis6 {
                width   : 32%;
                height  : 30%;
                background-color: #fff;
            }*/

            #all_gaugeDetails1 {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #all_gaugeDetails2 {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #all_gaugeDetails3 {
                width   : 100%;
                height  : 100px;
                background-color: #fff;
            }

            #all_pieDetails4 {
                width   : 100%;
                height  : 100px;
                /*padding-bottom: 0px !important;
                border-bottom: 0px !important;*/
                background-color: #fff;
            }

            #all_tabung1 {
                width   : 100%;
                height  : 230px;
                background-color: #EBEBEB;
            }

            #all_tabung2 {
                width   : 100%;
                height  : 230px;
                background-color: #EBEBEB;
                color:#fff;
            }

            #view-all-notif {
                border-top: 2px solid #bfb9b9;
                text-align: center;
                padding: 10px;
            }

            #view-all-notif a {
                color: white;
            }

            .yayan-1 {
                background-color: #009688; 
                border-color: #009688;
                color: #fff;
            }

            .yayan-11 {
                background-color: #f72c2ce8; 
                border-color: #009688;
                color: #fff;
            }
            .yayan-2{
                background-color: #f44336;
                border-color: #f44336;
                box-shadow: none;
                color:#fff;
            }
            .site-menu-item{
                font-size: xx-large;
            }
            .yayan-3{
                color:#009688;
            }

            .bg-info1 {
                background-color: #ff8d00 !important;
            }

            .not-1 {
                color: #f3ad0f;
            }
            .not-2 {
                color: #20c997;
            }
            .not-3 {
                color: #ff222c;
            }
            .not-4 {
                color: #343a40;
            }
        </style>
        <!-- BEGIN GLOBAL MANDATORY STYLES -->

        <link rel="apple-touch-icon" href="<?php echo base_url() ?>assets_remark/base/assets/images/apple-touch-icon.png">
        <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/img/icon.png">

        <!-- Stylesheets -->
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/css/bootstrap-extend.min.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/base/assets/css/site.css">

        <!-- Plugins -->
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/animsition/animsition.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/asscrollable/asScrollable.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/base/assets/examples/css/advanced/scrollable.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/switchery/switchery.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/intro-js/introjs.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/slidepanel/slidePanel.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/flag-icon-css/flag-icon.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/waves/waves.css">

        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/base/assets/examples/css/dashboard/v1.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/datatables.net-bs4/dataTables.bootstrap4.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/aspieprogress/asPieProgress.css">

        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">

        <!-- Fonts -->
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/fonts/font-awesome/font-awesome.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/fonts/material-design/material-design.min.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/fonts/brand-icons/brand-icons.min.css">
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,300italic'>

        <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/ammap/ammap/ammap.css" type="text/css">

        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/datatables.net-fixedheader-bs4/dataTables.fixedheader.bootstrap4.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/datatables.net-fixedcolumns-bs4/dataTables.fixedcolumns.bootstrap4.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/datatables.net-rowgroup-bs4/dataTables.rowgroup.bootstrap4.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/datatables.net-scroller-bs4/dataTables.scroller.bootstrap4.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/datatables.net-select-bs4/dataTables.select.bootstrap4.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/datatables.net-responsive-bs4/dataTables.responsive.bootstrap4.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/global/vendor/datatables.net-buttons-bs4/dataTables.buttons.bootstrap4.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/moris/morris.css">
        <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.css"/>
        <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/ammap/ammap/ammap.css" type="text/css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!-- <link rel="stylesheet" href="<?php echo base_url(); ?>assets/ammap/style.css" type="text/css"> -->

        <script src="<?php echo base_url() ?>assets_remark/global/vendor/breakpoints/breakpoints.js"></script>
        <script>Breakpoints()</script>    

    </head>


    <body class="animsition dashboard">


        <script src="<?php echo base_url() ?>assets_remark/global/vendor/babel-external-helpers/babel-external-helpers.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/jquery/jquery.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/popper-js/umd/popper.min.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/bootstrap/bootstrap.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/animsition/animsition.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/animsition/animsition.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/mousewheel/jquery.mousewheel.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/asscrollbar/jquery-asScrollbar.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/asscrollable/jquery-asScrollable.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/ashoverscroll/jquery-asHoverScroll.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/waves/waves.js"></script>

        <!-- Plugins -->
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/switchery/switchery.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/intro-js/intro.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/screenfull/screenfull.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/slidepanel/jquery-slidePanel.js"></script>


        <script src="<?php echo base_url() ?>assets_remark/global/vendor/matchheight/jquery.matchHeight-min.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/peity/jquery.peity.min.js"></script>


        <script src="<?php echo base_url() ?>assets_remark/global/vendor/datatables.net/jquery.dataTables.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/vendor/datatables.net-bs4/dataTables.bootstrap4.js"></script>

        <!-- Scripts -->
        <script src="<?php echo base_url() ?>assets_remark/global/js/Component.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/js/Plugin.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/js/Base.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/js/Config.js"></script>

        <script src="<?php echo base_url() ?>assets_remark/base/assets/js/Section/Menubar.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/base/assets/js/Section/GridMenu.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/base/assets/js/Section/Sidebar.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/base/assets/js/Section/PageAside.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/base/assets/js/Plugin/menu.js"></script>

        <script src="<?php echo base_url() ?>assets_remark/global/js/config/colors.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/base/assets/js/config/tour.js"></script>
        <script>Config.set('assets', '<?php echo base_url() ?>assets_remark/base/assets');</script>

        <!-- Page -->
        <script src="<?php echo base_url() ?>assets_remark/base/assets/js/Site.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/base/assets/examples/js/advanced/scrollable.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/js/Plugin/asscrollable.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/js/Plugin/slidepanel.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/js/Plugin/switchery.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/js/Plugin/matchheight.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/js/Plugin/jvectormap.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/js/Plugin/peity.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/global/js/Plugin/datatables.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/base/assets/examples/js/tables/datatable.js"></script>
        <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.2/raphael-min.js"></script>
        <script src="<?php echo base_url() ?>assets_remark/moris/morris.js"></script>   



        <link rel="stylesheet" href="<?php echo base_url() ?>assets_remark/base/assets/examples/css/uikit/modals.css">

        <nav class="site-navbar navbar navbar-default navbar-fixed-top navbar-mega" role="navigation">

            <div class="navbar-header" style="background-color:#F3F3F3 !important">
                <button type="button" class="navbar-toggler hamburger hamburger-close navbar-toggler-left hided"
                        data-toggle="menubar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="hamburger-bar"></span>
                </button>
                <button type="button" class="navbar-toggler collapsed" data-target="#site-navbar-collapse"
                        data-toggle="collapse">
                    <i class="icon md-more" aria-hidden="true"></i>
                </button>

                <div class="navbar-brand navbar-brand-center site-gridmenu-toggle" data-toggle="gridmenu" >
                    <img src="<?php echo base_url(); ?>assets/img/ipc_logo.png" alt="logo IPC" class="navbar-brand-logo"/>
                    <span class="navbar-brand-text hidden-xs-down" style="color: #1c2b39;font-size: 25px;font-weight: bold;margin-left: 30px"> CE-MS</span>
                </div>

                <button type="button" class="navbar-toggler collapsed" data-target="#site-navbar-search"
                        data-toggle="collapse">
                    <span class="sr-only">Toggle Search</span>
                    <i class="icon md-search" aria-hidden="true"></i>
                </button>
            </div>

            <div class="navbar-container container-fluid">
                <!-- Navbar Collapse -->
                <div class="collapse navbar-collapse navbar-collapse-toolbar" id="site-navbar-collapse">
                    <!-- Navbar Toolbar -->
                    <ul class="nav navbar-toolbar">

                        <li class="nav-item hidden-sm-down" id="toggleMenubar" style="padding-top:5px !important">
                            <a class="nav-link icon" data-toggle="menubar" href="#" role="button">
                                <i class="icon hamburger hamburger-arrow-left">
                                    <span class="sr-only">Toggle menubar</span>
                                    <span class="hamburger-bar"></span>
                                </i>
                            </a>
                        </li>
                        <li class="nav-item hidden-sm-down" id="toggleFullscreen">
                            <a class="nav-link icon icon-fullscreen" data-toggle="fullscreen" href="#" role="button">
                                <span class="sr-only">Toggle fullscreen</span>
                            </a>
                        </li>
                    </ul>

                    <!-- End Navbar Toolbar -->
                    <!-- Navbar Toolbar Right -->
                    <ul class="nav navbar-toolbar navbar-right navbar-toolbar-right">
                        <li class="nav-item dropdown">
                            <a class="nav-link" data-toggle="dropdown" href="javascript:void(0)" title="Notifications"
                               aria-expanded="false" data-animation="scale-up" role="button">
                                <i class="icon md-notifications" aria-hidden="true"></i>
                                <span class="badge badge-pill badge-danger up"><?php echo $notif_count; ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-media" role="menu">
                                <div class="dropdown-menu-header">
                                    <h5>NOTIFIKASI</h5>
                                </div>

                                <div class="list-group">
                                    <div data-role="container">
                                        <div data-role="content">
                                            <?php foreach ($notif_isi as $row): ?>
                                                <a class="list-group-item dropdown-item" href="<?php echo base_url('realisasi/view/') . $row->RKAP_SUBPRO_ID ?>" role="menuitem">
                                                    <div class="media">
                                                        <div class="pr-10">
                                                            <i class="icon fa-bullhorn bg-red-600 white icon-circle" aria-hidden="true"></i>
                                                        </div>
                                                        <div class="">
                                                            <span class="" style="white-space: normal !important;"><?php echo "Realisasi untuk investasi <z class='not-1'>$row->RKAP_INVS_TITLE</z> pada kontrak <z class='not-2'>$row->RKAP_SUBPRO_TITTLE</z> type <z class='not-3'>$row->SUBPRO_TYPE_NAME</z> baru sampai <z class='not-4'>$row->REAL_SUBPRO_DATE</z>"; ?> </span>

                                                        </div>
                                                    </div>
                                                </a>
                                            <?php endforeach; ?>



                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="dropdown-menu-footer">
                                  <a class="dropdown-menu-footer-btn" href="javascript:void(0)" role="button">
                                    <i class="icon md-settings" aria-hidden="true"></i>
                                  </a>
                                  <a class="dropdown-item" href="javascript:void(0)" role="menuitem">
                                    All notifications
                                  </a>
                                </div> -->
                            </div>
                        </li>            
                        <li class="nav-item dropdown">
                            <a class="nav-link navbar-avatar" data-toggle="dropdown" href="#" aria-expanded="false"
                               data-animation="scale-up" role="button">
                                <span class="avatar avatar-online">
                                    <img src="<?php echo base_url() ?>assets_remark/global/portraits/55.png" alt="...">
                                    <i></i>
                                </span>
                            </a>
                            <div class="dropdown-menu" role="menu">
                                <a class="dropdown-item" href="<?php echo base_url() ?>user/update_pass/<?php echo $this->session->userdata('SESS_USER_ID'); ?>" role="menuitem"><i class="icon md-settings" aria-hidden="true"></i> Ubah Password</a>
                                <div class="dropdown-divider" role="presentation"></div>
                                <a href="<?php echo base_url(); ?>logout/logout_konfirm/<?php echo $this->session->userdata('SESS_USER_ID'); ?>" class="dropdown-item">Logout</a>
                            </div>
                        </li>



                    </ul>
                    <!-- End Navbar Toolbar Right -->
                </div>



                <div class="collapse navbar-search-overlap" id="site-navbar-search">
                    <form role="search">
                        <div class="form-group">
                            <div class="input-search">
                                <i class="input-search-icon md-search" aria-hidden="true"></i>
                                <input type="text" class="form-control" name="site-search" placeholder="Search...">
                                <button type="button" class="input-search-close icon md-close" data-target="#site-navbar-search"
                                        data-toggle="collapse" aria-label="Close"></button>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- End Site Navbar Seach -->
            </div>
        </nav>    <div class="site-menubar">
            <div class="site-menubar-body">
                <div>
                    <div>
                        <ul class="site-menu" data-plugin="menu">
                            <li class="site-menu-category">Main Menu</li>
                            <li class="site-menu-item <?php
                            if ($this->uri->segment(1) == "home") {
                                echo"active";
                            }
                            ?>">
                                <a class="animsition-link" href="<?php echo base_url(); ?>home" style="color:#494949;">
                                    <i class="site-menu-icon md-view-web" aria-hidden="true"></i>
                                    <span class="site-menu-title">Dashboard</span>
                                    <span class="site-menu-arrow"></span>
                                </a>
                            </li>
                            <?php if ($this->session->userdata('SESS_USER_PRIV') == 1 && $this->session->userdata('SESS_USER_POSITION') == 1): ?>
                                <li class="site-menu-item has-sub <?php
                            if ($this->uri->segment(1) == "usermanagement") {
                                echo"active";
                            }
                            ?>">
                                    <a class="animsition-link yayan-3" href="javascript:void(0);" style="color:#494949;">
                                        <i class="site-menu-icon md-face" aria-hidden="true"></i>
                                        <span class="site-menu-title">User Manajemen</span>
                                        <span class="site-menu-arrow"></span>
                                    </a>
                                    <!-- perubahan sub menu user manajement -->
                                    <ul class="site-menu-sub">
                                        <li class="site-menu-item">
                                            <a class="animsition-link" href="<?php echo base_url(); ?>usermanagement">
                                                <span class="site-menu-title" style="font-size: large;">User Manajemen</span>
                                            </a>
                                        </li>
                                        <li class="site-menu-item">
                                            <a class="animsition-link" href="<?php echo base_url(); ?>setting/ews">
                                                <span class="site-menu-title" style="font-size: large;">User Manajemen desain</span>
                                            </a>
                                        </li>
                                        <li class="site-menu-item">
                                            <a class="animsition-link" href="<?php echo base_url(); ?>usermanagement/desain_user">
                                                <span class="site-menu-title" style="font-size: large;">User Manajemen 2</span>
                                            </a>
                                        </li>
                                        <li class="site-menu-item">
                                            <a class="animsition-link" href="<?php echo base_url(); ?>usermanagement/import_exc">
                                                <span class="site-menu-title" style="font-size: large;">Import Excel</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>



                                <!-- hdkjshd -->
                                <li class="site-menu-item has-sub">
                                    <a class="animsition-link yayan-3" href="javascript:void(0);" style="color:#494949;">
                                        <i class="site-menu-icon md-card-travel" aria-hidden="true"></i>
                                        <span class="site-menu-title">Investasi</span>
                                        <span class="site-menu-arrow"></span>
                                    </a>
                                    <!-- perubahan sub menu user manajement -->
                                    <ul class="site-menu-sub">
                                        <li class="site-menu-item">
                                            <a class="animsition-link" href="<?php echo base_url(); ?>rkapinvestasi">
                                                <span class="site-menu-title" style="font-size: medium;">RKAP Investasi</span>
                                            </a>
                                        </li>


                                        <li class="site-menu-item">
                                            <a class="animsition-link" href="javascript:void(0);">
                                                <span class="site-menu-title" style="font-size: medium;">PO Kontrak</span>
                                            </a>
                                        </li>

                                        <li class="site-menu-item">
                                            <a class="animsition-link" href="<?php echo base_url(); ?>rkapinvestasi/invest_project">
                                                <span class="site-menu-title" style="font-size: medium;">Investasi Project</span>
                                            </a>
                                        </li>
                                        <li class="site-menu-item">
                                            <a class="animsition-link" href="javascript:void(0);">
                                                <span class="site-menu-title" style="font-size: medium;">TTB Realisasi</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <!-- hfouafh -->
                                <!-- <li class="site-menu-item <!?php if ($this->uri->segment(1)=="rkapinvestasi") {echo"active";} ?>" id="rkapinvestasi">
                                    <a class="animsition-link yayan-3" href="<!?php echo base_url(); ?>rkapinvestasi" style="color:#494949;">
                                            <i class="site-menu-icon md-card-travel" aria-hidden="true"></i>
                                        <span class="site-menu-title">RKAP Investasi</span>
                                        <span class="site-menu-arrow"></span>
                                    </a>
                                </li> -->
                                <li class="site-menu-item <?php
                            if ($this->uri->segment(1) == "announcement") {
                                echo"active";
                            }
                                ?>" id="announcement">
                                    <a class="animsition-link yayan-3" href="<?php echo base_url(); ?>announcement" style="color:#494949;">
                                        <i class="site-menu-icon md-star-circle" aria-hidden="true"></i>
                                        <span class="site-menu-title">Pengumuman 
                                                <?php if ($this->session->userdata('SESS_USER_PRIV') == 1 && $this->session->userdata('SESS_USER_POSITION') == 1): ?>
                                                <?php elseif ($this->session->userdata('SESS_USER_PRIV') == 1 && $this->session->userdata('SESS_USER_POSITION') == 2): ?>
                                            <?php elseif ($this->session->userdata('SESS_USER_PRIV') == 1 && $this->session->userdata('SESS_USER_POSITION') == 3): ?>  
                                            <?php else: ?>
                                                <div class="pull-right">
        <?php if ($notif_announcement > 0): ?>
                                                        <span class="badge badge-danger"><?php echo $notif_announcement; ?> </span>
        <?php endif ?>
                                                </div>
                                <?php endif ?>

                                        </span>
                                        <span class="site-menu-arrow"></span>    
                                    </a>
                                </li>
                                <li class="site-menu-item has-sub <?php
                                if ($this->uri->segment(1) == "setting") {
                                    echo"active";
                                }
                                ?>">
                                    <a class="animsition-link yayan-3" href="javascript:void(0)" style="color:#494949;">
                                        <i class="site-menu-icon md-settings" aria-hidden="true"></i>
                                        <span class="site-menu-title">Settings</span>
                                        <span class="site-menu-arrow"></span>
                                    </a>

                                    <ul class="site-menu-sub">
                                        <li class="site-menu-item">
                                            <a class="animsition-link" href="<?php echo base_url(); ?>setting">
                                                <span class="site-menu-title" style="font-size: large;">Kontrak Kritis</span>
                                            </a>
                                        </li>
                                        <li class="site-menu-item">
                                            <a class="animsition-link" href="<?php echo base_url(); ?>setting/ews">
                                                <span class="site-menu-title" style="font-size: large;">Early Warning System</span>
                                            </a>
                                        </li>
                                    </ul>

                                </li>
                                <li class="site-menu-item <?php
                            if ($this->uri->segment(1) == "projectcostingcems") {
                                echo"active";
                            }
                                ?>" id="rkapinvestasi">
                                    <a class="animsition-link yayan-3" href="<?php echo base_url(); ?>projectcostingcems" style="color:#494949;">
                                        <i class="site-menu-icon md-refresh-sync" aria-hidden="true"></i>
                                        <span class="site-menu-title">Integrasi</span>
                                        <span class="badge badge-pill badge-danger up" style="margin-left: 40px;"><?php echo ($notif_integrasi->JML > 0) ? $notif_integrasi->JML : ''; ?></span>
                                        <span class="site-menu-arrow"></span>
                                    </a>
                                </li>
                            <?php else: ?>
                                <?php if ($this->session->userdata('SESS_USER_POSITION') != 4): ?>
                                    <li class="site-menu-item <?php
                            if ($this->uri->segment(1) == "rkapinvestasi") {
                                echo"active";
                            }
                                    ?>">
                                        <a class="animsition-link yayan-3" href="<?php echo base_url(); ?>rkapinvestasi" style="color:#494949;">
                                            <i class="site-menu-icon md-view-dashboard" aria-hidden="true"></i>
                                            <span class="site-menu-title">RKAP Investasi</span>
                                            <span class="site-menu-arrow"></span>
                                        </a>
                                    </li>
                                        <?php endif ?> 
                                        <?php if ($this->session->userdata('SESS_USER_POSITION') != 4): ?>
                                    <li class="site-menu-item <?php
                                                      if ($this->uri->segment(1) == "announcement") {
                                                          echo"active";
                                                      }
                                                      ?>">
                                        <a class="animsition-link yayan-3" href="<?php echo base_url(); ?>announcement" style="color:#494949;">
                                                    <?php if ($this->session->userdata('SESS_USER_PRIV') == 1): ?>
                                                <i class="site-menu-icon fa fa-upload"></i>
                                                    <?php else: ?>
                                                <i class="site-menu-icon fa fa-download"></i>
                                                <?php endif ?>

                                            <span class="site-menu-title <?php
                                        if ($this->uri->segment(1) == "rkapinvestasi") {
                                            echo"active";
                                        }
                                                ?>">Pengumuman  
        <?php if ($this->session->userdata('SESS_USER_PRIV') == 1 && $this->session->userdata('SESS_USER_POSITION') == 1): ?>
        <?php elseif ($this->session->userdata('SESS_USER_PRIV') == 1 && $this->session->userdata('SESS_USER_POSITION') == 2): ?>
        <?php elseif ($this->session->userdata('SESS_USER_PRIV') == 1 && $this->session->userdata('SESS_USER_POSITION') == 3): ?>  
        <?php else: ?>
                                                    <div class="pull-right">
            <?php if ($notif_announcement > 0): ?>
                                                            <span class="badge badge-danger"><?php echo $notif_announcement; ?> </span>
            <?php endif ?>
                                                    </div>
        <?php endif ?>
                                            </span>
                                            <span class="site-menu-arrow"></span>
                                        </a>
                                    </li>
    <?php endif ?>    
<?php endif ?>



                            <!---Settings-->

                            <li class="site-menu-item has-sub" style="display:none">
                                <a href="javascript:void(0)">
                                    <i class="site-menu-icon md-view-compact" aria-hidden="true"></i>
                                    <span class="site-menu-title">Settings</span>
                                    <span class="site-menu-arrow"></span>
                                </a>
                                <ul class="site-menu-sub">
                                    <li class="site-menu-item">
                                        <a class="animsition-link" href="layouts/menu-collapsed.html">
                                            <span class="site-menu-title">Menu Collapsed</span>
                                        </a>
                                    </li>
                                    <li class="site-menu-item">
                                        <a class="animsition-link" href="layouts/menu-expended.html">
                                            <span class="site-menu-title">Menu Expended</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>


                        </ul>



                        <div class="site-menubar-section" style="display:none">
                            <h5>
                                RKAP
                                <span class="float-right">30%</span>
                            </h5>
                            <div class="progress progress-xs">
                                <div class="progress-bar active" style="width: 30%;" role="progressbar"></div>
                            </div>
                            <h5>
                                Realisasi
                                <span class="float-right">60%</span>
                            </h5>
                            <div class="progress progress-xs">
                                <div class="progress-bar progress-bar-warning" style="width: 60%;" role="progressbar"></div>
                            </div>
                        </div>
                    </div>



                </div>
            </div>

            <div class="site-menubar-footer" style="display:none">
                <a href="<?php echo base_url(); ?>logout/logout_konfirm/<?php echo $this->session->userdata('SESS_USER_ID'); ?>" data-placement="top" data-toggle="tooltip" data-original-title="Logout">
                    <span class="icon md-power" aria-hidden="true" style="width:100% !important"></span>
                </a>
            </div>
        </div>    



        <!-- Page -->

        <!-- End Panel Projects Stats -->

        <!-- Footer -->

        <!-- Core  -->

        <div id="myModal" class="modal fade modal-rotate-from-left modal-warning" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" tabindex="-1">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Konfirmasi</h4>
                    </div>
                    <div class="modal-body">
                        <p>Apakah anda yakin ingin keluar ?</p>
                    </div>
                    <div class="modal-footer">

                        <button type="button" class="btn btn-default btn-pure" data-dismiss="modal"><div class="fa fa-times"></div> Tidak</button>
                        <a href="<?php echo base_url(); ?>logout/logout_konfirm/<?php echo $this->session->userdata('SESS_USER_ID'); ?>" class="btn btn-success"><div class="fa fa-check"></div> Ya</a>
                    </div>
                </div>

            </div>
        </div>
